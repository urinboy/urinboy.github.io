/* ** Misol #6.1** */

let students = ['Bobur', 'Shaxriyor', 'Shaxobiddin', 'Sardor'];
students.unshift('Abduvahob');
document.getElementById("natija1").innerHTML = students;
console.log(students);
students.push('Muhammadjon');
console.log(students);
document.getElementById("natija2").innerHTML = students;