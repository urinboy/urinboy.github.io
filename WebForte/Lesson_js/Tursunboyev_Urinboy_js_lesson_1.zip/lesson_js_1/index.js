/* ** Misol #1** */
var a = 10;
var b = 12;
var c = 16;
var misol_1 = (a + b + c)/3;
console.log('1-misol: ', 'a = ', a, ', b = ', b, ', c = ', c, ',  o`rta_arf = ', misol_1);

/* ** Misol #2** */
var kv_a = 16;
var kv_P = 4 * kv_a;
var kv_S = kv_a * kv_a;
console.log('2-misol: ',  'a = ', kv_a, ', Peremetri:', kv_P, ', Yuzasi:', kv_S);

/* ** Misol #3** */
var t_a = 23;
var t_b = 13;
var t_P = 2 * (t_a + t_b);
var t_S = t_a * t_b;
console.log('3-misol: ',  'a = ', t_a,  ', b = ', t_b, ', Peremetri:', t_P, ', Yuzasi:', t_S);

/* ** Misol #4** */
var v = 25;
var t = 30;
var S = v * t;
console.log('4-misol: ',  'v = ', v,  ', t = ', t, ', S = :', S);

/* ** Misol #5** */
var u_a = 3;
var u_b = 4;
var u_c = 5;
var u_P = (a + b + c);
console.log('5-misol: ', 'a = ', u_a, ', b = ', u_b, ', c = ', u_c, ',  P = ', u_P);
