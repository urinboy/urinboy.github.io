/* ** Misol #4** */

var a = parseInt(prompt("a sonini kiriting"));
console.log('2.4 - misol: a = ', a);
var result = (a % 2 === 0);
console.log('a soni juft sonmi : ', result);