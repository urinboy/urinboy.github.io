/* ** Misol #3** */

var a = parseInt(prompt("a sonini kiriting"));
var b = parseInt(prompt("b sonini kiriting"));
console.log('2.3 - misol: a = ', a, ', b = ', b);
var result = ((a % 2 === 1) && (b % 2 === 1));
console.log('a va b toq sonlar : ', result);