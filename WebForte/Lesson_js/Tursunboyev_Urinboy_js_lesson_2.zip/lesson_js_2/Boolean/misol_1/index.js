/* ** Misol #1** */

var a = parseInt(prompt("a sonini kiriting"));
var b = parseInt(prompt("b sonini kiriting"));
   console.log('2.1 - misol: a = ', a, ', b = ', b);
var result = (a > 2 && b < 10);
console.log('a > 2 va b < 10 : ', result);