/* ** Misol #2** */

var a = parseInt(prompt("a sonini kiriting"));
var b = parseInt(prompt("b sonini kiriting"));
var c = parseInt(prompt("c sonini kiriting"));
   console.log('2.1 - misol: a = ', a, ', b = ', b, ', c = ', c);
var result = (a < b && b < c);
console.log('a < b < c : ', result);