/* ** Misol #5** */

var a = parseInt(prompt("a sonini kiriting"));
console.log('2.5 - misol: a = ', a);
var result = (a > 9 && a < 100);
console.log('a soni juft sonmi : ', result);