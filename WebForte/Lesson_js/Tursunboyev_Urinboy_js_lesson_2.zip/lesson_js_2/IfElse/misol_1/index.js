/* ** Misol #1** */

var a = parseInt(prompt("a sonini kiriting"));
console.log('2.2.1 - misol: a = ', a);
if(a > 0){
    a++;
}else{
    a *= 10;
}
console.log('Natija : ', a);