/* ** Misol #2** */

var a = parseInt(prompt("a sonini kiriting"));
var b = parseInt(prompt("b sonini kiriting"));
console.log('2.2.2 - misol: a = ', a, ', b = ', b);
if(a > b){
    console.log('Kattasi: a = ', a );
}else{
    console.log('Kattasi: b = ', b );
}
