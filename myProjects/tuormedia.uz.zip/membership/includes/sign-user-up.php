<?php
    require __DIR__. '/../config/dbconnect.php'; // database connection
    require __DIR__. '/../classes/model.class.php'; // Model


    $dbhandler = new Config() ;
    $Model = new Model($dbhandler);

    if ( isset($_POST) && !empty($_POST) ) 
    {

        if ( !$return = $Model->validateForm($_POST)  ) 
        {
            if ($_POST['password'] === $_POST['repassword']) {

                $email      =  filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
                $password   =  $_POST['password'];


                if (!$Model->emailAlreadyUsed($email)) 
                {
                    if ($Model->addUser($email, $password)) 
                    {
                        session::set('confirmation', 'You have successfully signed up!');
                        // If you want to can send a confirmation email here

                    }else{
                        session::set('error_general', 'Something went wrong.');
                    }
                }else{
                    session::set('error_email', 'This email is already used.');
                }

            }else{
                session::set('error_repassword', 'The two passwords are not the same.');
            }

        }else{
            foreach ($return as $field => $error) {
                session::set($field, $error);
            }
        }

    }