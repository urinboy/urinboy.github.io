
  <!-- Favicons -->
  <link href="/styles/img/favicon.png" rel="icon">
  <link href="/styles/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="/styles/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="/styles/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="/styles/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="/styles/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="/styles/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="/styles/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="/styles/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="/styles/vendor/aos/aos.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" />

  <!-- Template Main CSS File -->
  <link href="/styles/css/style.css" rel="stylesheet">
  <link href="/styles/player.css" rel="stylesheet">
  <style>
      body{
    margin-top:20px;
    color: #1a202c;
    text-align: left;
    background-color: #e2e8f0;    
}
.main-body {
    padding: 15px;
}
.card {
    box-shadow: 0 1px 3px 0 rgba(0,0,0,.1), 0 1px 2px 0 rgba(0,0,0,.06);
}

.card {
    position: relative;
    display: flex;
    flex-direction: column;
    min-width: 0;
    word-wrap: break-word;
    background-color: #fff;
    background-clip: border-box;
    border: 0 solid rgba(0,0,0,.125);
    border-radius: .25rem;
}

.card-body {
    flex: 1 1 auto;
    min-height: 1px;
    padding: 1rem;
}

.gutters-sm {
    margin-right: -8px;
    margin-left: -8px;
}

.gutters-sm>.col, .gutters-sm>[class*=col-] {
    padding-right: 8px;
    padding-left: 8px;
}
.mb-3, .my-3 {
    margin-bottom: 1rem!important;
}

.bg-gray-300 {
    background-color: #e2e8f0;
}
.h-100 {
    height: 100%!important;
}
.shadow-none {
    box-shadow: none!important;
}

  .divider-text{
    position:relative;
    text-align:center;
    margin-top:15px;
    margin-bottom:15px;
  }
  .divider-text span{
    padding:7px;
    font-size:12px;
    position:relative;
    z-index: 2;
  }
  .divider-text:after{
    content:"";
    position: absolute;
    width: 100%;
    border: 1px solid #ddd;
    top: 55%;
    left:0;
    z-index:1;
  }
  .btn-facebook{
    background-color:#405d9d!important;
    color:#fff!important;
  }
  .btn-gmail{
    background-color:#ea4335!important;
    color:#fff!important;
  }
@import url('https://fonts.googleapis.com/css2?family=Galada&family=Texturina&display=swap');

.form-div{
  width:70%;
  font-family: 'Texturina', serif;
  margin: 50px auto 50px;
  padding: 25px 15px 10px 15px;
  border: 1px solid #80ced7;
  border-radius: 5px;
  font-size: 1.1em;
}
h3.card-title{


   font-family: 'Texturina', serif;
}

.form-control:focus {
  box-shadow: none;
}
form p{
    font-fahmily: 'Galada', cursive;
    font-size:.89em;
}
@media (max-width: 1080px) {
    .form-div{
        width:70%;
    }
}
@media (max-width: 970px) {
    .form-div{
        width:80%;
    }
}
@media (max-width: 670px) {
    .form-div{
        width:90%;
    }
}

  </style>