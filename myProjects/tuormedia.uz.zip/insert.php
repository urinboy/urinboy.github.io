<?php

header("refresh: 5; /kiritish.php");
$errors = array();
$alert = array();

/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "test");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Escape user inputs for security
$first_name = mysqli_real_escape_string($link, $_REQUEST['first_name']);
$last_name = mysqli_real_escape_string($link, $_REQUEST['last_name']);
$email = mysqli_real_escape_string($link, $_REQUEST['email']);
 
// attempt insert query execution
$sql = "INSERT INTO persons (first_name, last_name, email_demo) VALUES ('$first_name', '$last_name', '$email')";
if(mysqli_query($link, $sql)){
    $errors['insert'] = "Records added successfully.";
} else{
    $errors['error'] = "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// close connection
mysqli_close($link);

$page_id = '';
$page_url = "/insert.php";
$title = "Bazaga kiritish";
$site_name = "TUORMedia.uz";
include "includes/header.php";
?>

    <!-- ======= Login Section ======= -->
    <section id="login" class="blog">
      <div class="container">
                    
            <div class="row" data-aos="fade-up" data-aos-delay="100">
                <div class="col-md-4 offset-md-4 form-div">
                <form method="post" action="insert.php">
                    <div class="section-title" data-aos="fade-up" data-aos-delay="300">
                     <h3 class="text-center">Bazaga kiritildi</h3>
                    </div>
                   <?php if(count($errors) > 0): ?>
					<div class="alert <?php 
					if($errors['insert']){ 
						echo $alert['alert-class'] = "alert-success";
					}else {
						echo $alert['alert-class'] = "alert-danger";
					} ?>">
                     <?php foreach($errors as $error): ?>
                        <li style="list-style-type:none;"><?php echo $error; ?></li>
                        <?php endforeach; ?>
                    </div> 
                    <?php endif; ?>

                    <div class="form-group" data-aos="fade-up" data-aos-delay="400">
                    <label for="firstName">Ismingiz:</label> <?php echo $first_name; ?>
                    </div>
                    <div class="form-group" data-aos="fade-up" data-aos-delay="400">
                    <label for="lastName">Familiya:</label> <?php echo $last_name; ?>
                    </div>
                    <div class="form-group" data-aos="fade-up" data-aos-delay="400">
                    <label for="emailAddress">Email Address:</label> <?php echo $email; ?>
                    </div>
                    <p class="text-center" data-aos="fade-up" data-aos-delay="400"><a href="kiritish.php">Bazaga kiritish</a></p>
                </form>
                </div>
            </div>
      </div>
    </section><!-- End Login Section -->

	<?php include "includes/footer.php"; ?>