<?php

$page_id = '';
$page_lang = "uz";
$url = "http://tuormedia.uz/mp3lar.php";
$category = "Sheriyat";
$title = "O'zimizning eng sara Qo'shiqlar";
$site_name = "TUORMedia.uz";
$description = "O'zimizning eng sara Qo'shiqlar";
$keywords = " O'zimizning eng sara Qo'shiqlar, tuormedia.uz, She'riyat, O'zimizning eng sara, Qo'shiqlar, Shoir, ijodkor 2020";
$local = "Taxiatosh tumani, Keneges OFY";
$image = "http://tuormedia.uz/styles/img/favicon.png";

include "includes/header.php";
?>
<style>
  .vid{
    width:520px;
    height:270px;
  }
</style>
    <!-- ======= Team Section ======= -->
    <section id="team" class="team section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Honanda Ijodi</h2>
          <p></p>
        </div>

        <div class="row">
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
            <div class="member d-flex align-items-start">
            <img src="/mp3/xay.jpg" width="100%" height="100%" style="border-radius:6px;" alt="Xayrulla Adilov"/>
          </div>
          </div>
          <div class="col-lg-6 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="100">
            <div class="member d-flex align-items-start">
            <div class="body container2">
            <div class="body container2">
            <audio id="audio" preload="none" tabindex="0">
              <source src="http://tuormedia.uz/mp3/eslаtmа_xayrullа_adilov_tuormedia.uz.mp3" data-track-number="1" />
              <source src="http://tuormedia.uz/mp3/Jonim_Хayrulla_Odilov_tuormedia.uz.mp3" data-track-number="2" />
              <source src="http://tuormedia.uz/mp3/Yugura_yugura_Xayrulla_Odilov_tuormedia.uz_new.mp3" data-track-number="3" />
              <source src="http://tuormedia.uz/mp3/Xayrulla_Adilov_Jonim_boqishing_new_tuormedia.uz.mp3" data-track-number="4" />
              <source src="http://tuormedia.uz/mp3/Xayrulla_Adilov_Kuladi_turomedia.uz.mp3" data-track-number="5" />    
              <source src="http://tuormedia.uz/mp3/Xayrulla_Adilov_Uzun_tuormedia.uz.mp3" data-track-number="6" />
              Your browser does not support HTML5 audio.
          </audio>

          <div class="player">

            <div class="large-toggle-btn">
              <i class="large-play-btn"><span class="screen-reader-text">Large toggle button</span></i>
            </div>
            <!-- /.play-box -->

            <div class="info-box">
              <div class="track-info-box">
                <div class="track-title-text"></div>
                <div class="audio-time">
                  <span class="current-time">00:00</span> /
                  <span class="duration">00:00</span>
                </div>
              </div>
              <!-- /.info-box -->

            <div class="progress-box">
              <div class="progress-cell">
                <div class="progress">
                  <div class="progress-buffer"></div>
                  <div class="progress-indicator"></div>
                </div>
              </div>
            </div>
          </div>
          <!-- /.progress-box -->

          <div class="controls-box">
            <i class="previous-track-btn disabled"><span class="screen-reader-text">Previous track button</span></i>
            <i class="next-track-btn"><span class="screen-reader-text">Next track button</span></i>
          </div>
          <!-- /.controls-box -->
        </div>
        <!-- /.player -->
          <div class="play-list">
            <div class="play-list-row" data-track-row="1">
              <div class="small-toggle-btn">
                <i class="small-play-btn"><span class="screen-reader-text">Small toggle button</span></i>
              </div>
              <div class="track-number">
                1.
              </div>
              <div class="track-title">
                <a class="playlist-track" href="#" data-play-track="1">Xayrulla Adilov - Eslatma</a>
              </div>
            </div>
            <div class="play-list-row" data-track-row="2">
              <div class="small-toggle-btn">
                <i class="small-play-btn"><span class="screen-reader-text">Small toggle button</span></i>
              </div>
              <div class="track-number">
                2.
              </div>
              <div class="track-title">
                <a class="playlist-track" href="#" data-play-track="2">Xayrulla Adilov - Jonim</a>
              </div>
            </div>
            <div class="play-list-row" data-track-row="3">
              <div class="small-toggle-btn">
                <i class="small-play-btn"><span class="screen-reader-text">Small toggle button</span></i>
              </div>
              <div class="track-number">
                3.
              </div>
              <div class="track-title">
                <a class="playlist-track" href="#" data-play-track="3">Xayrulla Adilov - Yugura yugura</a>
              </div>
            </div>
            <div class="play-list-row" data-track-row="4">
              <div class="small-toggle-btn">
                <i class="small-play-btn"><span class="screen-reader-text">Small toggle button</span></i>
              </div>
              <div class="track-number">
                4.
              </div>
              <div class="track-title">
                <a class="playlist-track" href="#" data-play-track="4">Xayrulla Adilov - Jonim boqishing new</a>
              </div>
            </div>
            <div class="play-list-row" data-track-row="5">
              <div class="small-toggle-btn">
                <i class="small-play-btn"><span class="screen-reader-text">Small toggle button</span></i>
              </div>
              <div class="track-number">
                5.
              </div>
              <div class="track-title">
                <a class="playlist-track" href="#" data-play-track="5">Xayrulla Adilov - Kuladi</a>
              </div>
            </div>
            <div class="play-list-row" data-track-row="6">
              <div class="small-toggle-btn">
                <i class="small-play-btn"><span class="screen-reader-text">Small toggle button</span></i>
              </div>
              <div class="track-number">
                6.
              </div>
              <div class="track-title">
                <a class="playlist-track" href="#" data-play-track="6">Xayrulla Adilov - Uzun</a>
              </div>
            </div>
            
          </div>
          </div>
        </div>
       </div>
      </div>

      <div class="col-lg-6 mt-4" data-aos="fade-up" data-aos-delay="300">
            <div class="member d-flex align-items-start">
              <iframe class="vid" src="https://www.youtube.com/embed/E5a4r9nxAdk" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
          </div>
          <div class="col-lg-6 mt-4" data-aos="fade-up" data-aos-delay="400">
            <div class="member d-flex align-items-start">
              <iframe class="vid" src="https://www.youtube.com/embed/6jeH-AXl_RI" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
          </div>

          <div class="col-lg-6 mt-4" data-aos="fade-up" data-aos-delay="300">
            <div class="member d-flex align-items-start">
            <iframe class="vid" src="https://www.youtube.com/embed/Vmerv4D6seI" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
          </div>
          <div class="col-lg-6 mt-4" data-aos="fade-up" data-aos-delay="400">
            <div class="member d-flex align-items-start">
              <iframe class="vid" src="https://www.youtube.com/embed/3EfUQu_5-XE" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
          </div>
          <div class="col-lg-6 mt-4" data-aos="fade-up" data-aos-delay="300">
            <div class="member d-flex align-items-start">
            <iframe class="vid" src="https://www.youtube.com/embed/1fR7DFDaixU" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
          </div>


        </div>
      </div>
    </section><!-- End Team Section -->

                  
<script src="/player.js"></script>

<?php
include "includes/footer.php";
?>