<?php
  include "db.php";
/*
if (!$con) {
  die("Ulanishda xatolik: " . mysqli_connect_error());
}*/

// sql to create table
$sql = "CREATE TABLE Foydalanuvchi (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
firstname VARCHAR(30) NOT NULL,
lastname VARCHAR(30) NOT NULL,
email VARCHAR(50),
reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if (mysqli_query($con, $sql)) {
  echo "Foydalanuvchi ro`yxati yaratildi";
} else {
  echo "Ro`yxatni yaratishda xatolik: " . mysqli_error($con);
}

mysqli_close($conn);
?>