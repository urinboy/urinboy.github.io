<?php include "db.php";
if((isset($_POST['kititish']))){
  $dori_name = $_POST['dori_name'];
  $izox = $_POST['izox'];
  $dtype_name = $_POST['dtype_name'];
  $olchov_name = $_POST['olchov_name'];
     /* $query ="INSERT INTO dori(DORI_NAME, DORI_IZOX, DTYPE_NAME,OLCHOV_NAME) VALUES('$dori_name','$izox','$dtype_name','$olchov_name')";
$fire mysqli_query($con, $query) or die("Ma`lumot kiritishda xatolik").mysqli_error($con);
if($fire) echo "Bazaga kiritildi";*/
}


 ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equive="X-UA-Comptible" content="ie=edge">
<title>Apteka</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  
</head>

<body>

<div class="jumbotron text-center">
  <h1>Apteka</h1>
  <p>Tursunboyev O`rinboy</p> 
 <div class="text-center"><?php echo date("d.m.Y"); ?></div>
</div>

<div class="container">
  <div class="alert alert-success>
     <?php print $dori_name." ".$izox." ".$dtype_name." ".$olchov_name; ?></div>

  <div class="row">
    <div class="col-sm-4">
      <h3>Kiritish</h3>
<form action="index.php" method="post"> 
<div class="form-row"> 
<div class="form-group col-md-6">
 <label for="dori_name">Dori nomi</label> <input type="text" class="form-control" id="dori_name" name="dori_name" placeholder="Dori nomi">
 </div>
 <div class="form-group col-md-6">
 <label for="izox">Izoh</label> 
<input type="text" class="form-control" id="izox" name="izox" placeholder="Izox">
 </div>
 </div>
 <div class="form-group">
 <label for="dtype_name">Dori turi</label>
 <input type="text" class="form-control" id="dtype_name" name="dtype_name" placeholder="Dori turi">
 </div>
 <div class="form-group col-md-4"> 
<label for="olchov_name">O`lchov</label> 
<select id="olchov_name" name="olchov_name" class="form-control"> 
<option selected>Tanlanmagan</option>
<?php
$olcham = "SELECT olchov_id, olchov_name, olchov_full FROM olchov";
$rolchov = $con->query($olchov);
if($rolchov->num_rows > 0){
 while($row = $rolchov-> fetch_assoc()){
echo "<option>".$row['OLCHOV_ID']." ".$row['OLCHOV_NAME']." ".$row['OLCHOV_FULL']."</option>";
}

?>
</select> 
</div> 
 <button name="kiritish" id="kiritish" class="btn btn-primary">Kiritish</button> 
</form>
    </div>
    <div class="col-sm-4">
      <h3>Column 2</h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit...</p>
      <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...</p>
    </div>
    <div class="col-sm-4">
      <h3>Column 3</h3>        
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit...</p>
      <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...</p>
    </div>
  </div>
</div>







<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
