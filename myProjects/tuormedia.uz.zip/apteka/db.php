<?php 
 define("HOSTNAME","localhost");
 define("USERNAME","tuormedia_apteka");
 define("PASSWORD","Salom@1196");
 define("DBNAME","tuormedia_apteka");

 $con = mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DBNAME) or die("Baza topilmadi.");

//if($con) echo "Bazaga ulandi.";

?>