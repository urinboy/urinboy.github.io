<?php

$page_id = '';
$page_lang = "uz";
$url = "http://tuormedia.uz/ulugbek_matniyozov.php";
$category = "Videolar";
$title = "Dilsodbek Muminov";
$site_name = "TUORMedia.uz";
$description = "Dilsodbek Muminov";
$keywords = " Dilsodbek Muminov, tuormedia.uz, She'riyat, O'zimizning eng sara, Qo'shiqlar, Shoir, ijodkor 2020";
$local = "Taxiatosh tumani, Keneges OFY";
$image = "http://tuormedia.uz/styles/img/favicon.png";

include "includes/header.php";
?>
<style>
  .vid{
    width:520px;
    height:270px;
  }
</style>


<!-- ======= Team Section ======= -->
    <section id="team" class="team section-bg">
      <div class="container" data-aos="fade-up">
        <div class="section-title">
          <h2>Qiziqarli Videolar</h2>
          <p></p>
        </div>
        <div class="row">
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
            <div class="member d-flex align-items-start">
            <img src="http://tuormedia.uz/styles/img/portfolio/Logopit.png" width="100%" height="100%" style="border-radius:6px;" alt="Xayrulla Adilov"/>
          </div>
          </div>
          <div class="col-lg-6 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="100">
            <div class="member d-flex align-items-start" style="padding: 10px;">    
            <video width="100%" height="100%" controls style="border-radius: 10px;">
                <source src="clip/dup/Dilshod_uchun_praktika.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
            </div>
          </div>
        </div>
       </div>
      </div>



        </div>
      </div>
    </section><!-- End Team Section -->
                  
<script src="/player.js"></script>

<?php
include "includes/footer.php";
?>