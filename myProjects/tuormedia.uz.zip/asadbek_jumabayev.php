<?php

$page_id = '';
$page_lang = "uz";
$url = "http://tuormedia.uz/ulugbek_matniyozov.php";
$category = "Musiqalar";
$title = "Asadbek Jumabayev";
$site_name = "TUORMedia.uz";
$description = "Asadbek Jumabayev";
$keywords = " Asadbek Jumabayev, tuormedia.uz, Musiqalar, Taronalar, She'riyat, O'zimizning eng sara, Qo'shiqlar, Shoir, ijodkor 2020";
$local = "Taxiatosh tumani, Keneges OFY";
$image = "http://tuormedia.uz/styles/img/favicon.png";

include "includes/header.php";
?>
<style>
  .vid{
    width:520px;
    height:270px;
  }
</style>
<object width="100%" height="650px" data="asadbek_jumabayev.html"></object>               

<!-- ======= Team Section ======= -->
    <section id="team" class="team section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Honanda Ijodi</h2>
          <p></p>
        </div>

        <div class="row">
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
            <div class="member d-flex align-items-start">
            <img src="http://tuormedia.uz/styles/img/portfolio/Logopit.png" width="100%" height="100%" style="border-radius:6px;" alt="Asadbek Jumabayev"/>
          </div>
          </div>
          <div class="col-lg-6 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="100">
            <div class="member d-flex align-items-start">
                
                <ol>
                <h4>Eng sara taronalar</h4><br>
          
                    <li> Botdi manga</li>
                    <li> Avadan</li>
                    <li> Dikkir dikkir</li>
                    <li> Go`zlaring yomon</li>
                    <li> Ey mozoli</li>
                    <li> Botdi mongo</li>
                    <li> Gech Remix</li>
                    <li> Jonim songo</li>
                    <li> Partsezd City</li>
                    <li> Super</li>
                    <li> San garak</li>
                    <li> Saribiyim sarisi</li>
                    <li> U hali bilmas</li>
                    <li> Zo`r qiz akan</li>
                    <li> Popuri</li>
                </ol>
            </div>
          </div>
        </div>
       </div>
      </div>



        </div>
      </div>
    </section><!-- End Team Section -->

                  
<script src="/player.js"></script>

<?php
include "includes/footer.php";
?>