
  <meta content="4-mavzu savoli:
Relyatsion maʼlumot modelning boshqa maʼlumot modellardan farqi. Relyatsion amallarga misol keltiring!" name="descriptison">
  <meta content="
Javobi:
Relyatsion MBBTda maʼlumotlar bilan ishlash uchun bir qancha tillar yaratilgan. 
Baʼzi hollarda bu tillarni maʼlumotlarni qism tillari deb ataladi. 
MB bilanishlovchilar bu tillarda avtomatlashtirishni 3 bosqich gaboʼlishadi: 

Eng pastki bosqich – kortej. - Bunda dasturchi yozuvlar yoki kortejlar bilan ishlaydi. 

Relyatsion algebra. - Bunda foydalanuvchi munosabatlar ustida yuqori bosqichli amallar toʼplamini kiritadi.
 
Eng yuqori bosqich –hisoblash bosqichi. - Bunda foydalanuvchi bevosita kompьyuterga
maxsus tillarda murojaat qiladi va mashina bu murojaatni qabul qiladi.

Misollardagi  belgilarni saytda ko'rsatmayapti. Shunga manzil http://tuormedia.uz/testform/4-mavzu.php

Birlashtirish(U).
SQLda UNION amali 𝑹𝟏 𝑼𝑵𝑰𝑶𝑵 𝑹𝟐
Kesishma(∩).
SQLda INTERSECT amali 𝑹𝟏 𝑰𝑵𝑻𝑬𝑹𝑺𝑬𝑪𝑻 𝑹𝟐
Аyirish(–).
SQLda EXCEPT amali 𝑹𝟏 𝑬𝑿𝑪𝑬𝑷𝑻 𝑹𝟐
Dekart koʼpaytma(*).
SQLda EXCEPT amali 𝑺𝒆𝒍𝒆𝒄𝒕 ∗ 𝑭𝒓𝒐𝒎 𝑹𝟏,𝑹𝟐
Selektsiya tanlash(𝝈).
𝝈𝑨𝟏𝜣𝑨𝟐(𝑹)
SQLda WHERE amali 𝑺𝒆𝒍𝒆𝒄𝒕 ∗ 𝑭𝒓𝒐𝒎 𝑹 𝑾𝒉𝒆𝒓𝒆 𝑷𝒓𝒊𝒄𝒆>𝟑𝟎
Proektsiya(𝝅).
𝝅𝑨𝟏,𝑨𝟐,...,𝑨𝑵(𝑹)
SQLda WHERE amali 𝑺𝒆𝒍𝒆𝒄𝒕 𝑵𝒂𝒎𝒆, 𝑾𝒆𝒊𝒈𝒉𝒕 𝑭𝒓𝒐𝒎 𝑹 𝑾𝒉𝒆𝒓𝒆 𝑷𝒓𝒊𝒄𝒆 < 𝟒𝟎
Ulash (⋈).
𝑹𝟏⋈𝑹𝟐
SQLda JOIN amali 𝑺𝒆𝒍𝒆𝒄𝒕 𝑹𝟏.𝑨,𝑹𝟏.𝑩,𝑹𝟐.𝑩,𝑹𝟐.𝑪 𝑭𝒓𝒐𝒎 𝑹𝟏 𝑰𝒏𝒏𝒆𝒓 𝑱𝒐𝒊𝒏 𝑹𝟐(𝑹𝟏.𝑩=𝑹𝟐.𝑩) 
Boʼlish (/).
𝑹𝟏÷𝑹𝟐" name="keywords">


<pre>
4-mavzu savoli:
Relyatsion maʼlumot modelning boshqa maʼlumot modellardan farqi. Relyatsion amallarga misol keltiring!

Javobi:
Relyatsion MBBTda maʼlumotlar bilan ishlash uchun bir qancha tillar yaratilgan. 
Baʼzi hollarda bu tillarni maʼlumotlarni qism tillari deb ataladi. 
MB bilanishlovchilar bu tillarda avtomatlashtirishni 3 bosqich gaboʼlishadi: 

Eng pastki bosqich – kortej. - Bunda dasturchi yozuvlar yoki kortejlar bilan ishlaydi. 

Relyatsion algebra. - Bunda foydalanuvchi munosabatlar ustida yuqori bosqichli amallar toʼplamini kiritadi.
 
Eng yuqori bosqich –hisoblash bosqichi. - Bunda foydalanuvchi bevosita kompьyuterga
maxsus tillarda murojaat qiladi va mashina bu murojaatni qabul qiladi.

Misollardagi  belgilarni saytda ko'rsatmayapti. Shunga manzil http://tuormedia.uz/testform/4-mavzu.php

Birlashtirish(U).
SQLda UNION amali 𝑹𝟏 𝑼𝑵𝑰𝑶𝑵 𝑹𝟐
Kesishma(∩).
SQLda INTERSECT amali 𝑹𝟏 𝑰𝑵𝑻𝑬𝑹𝑺𝑬𝑪𝑻 𝑹𝟐
Аyirish(–).
SQLda EXCEPT amali 𝑹𝟏 𝑬𝑿𝑪𝑬𝑷𝑻 𝑹𝟐
Dekart koʼpaytma(*).
SQLda EXCEPT amali 𝑺𝒆𝒍𝒆𝒄𝒕 ∗ 𝑭𝒓𝒐𝒎 𝑹𝟏,𝑹𝟐
Selektsiya tanlash(𝝈).
𝝈𝑨𝟏𝜣𝑨𝟐(𝑹)
SQLda WHERE amali 𝑺𝒆𝒍𝒆𝒄𝒕 ∗ 𝑭𝒓𝒐𝒎 𝑹 𝑾𝒉𝒆𝒓𝒆 𝑷𝒓𝒊𝒄𝒆>𝟑𝟎
Proektsiya(𝝅).
𝝅𝑨𝟏,𝑨𝟐,...,𝑨𝑵(𝑹)
SQLda WHERE amali 𝑺𝒆𝒍𝒆𝒄𝒕 𝑵𝒂𝒎𝒆, 𝑾𝒆𝒊𝒈𝒉𝒕 𝑭𝒓𝒐𝒎 𝑹 𝑾𝒉𝒆𝒓𝒆 𝑷𝒓𝒊𝒄𝒆 < 𝟒𝟎
Ulash (⋈).
𝑹𝟏⋈𝑹𝟐
SQLda JOIN amali 𝑺𝒆𝒍𝒆𝒄𝒕 𝑹𝟏.𝑨,𝑹𝟏.𝑩,𝑹𝟐.𝑩,𝑹𝟐.𝑪 𝑭𝒓𝒐𝒎 𝑹𝟏 𝑰𝒏𝒏𝒆𝒓 𝑱𝒐𝒊𝒏 𝑹𝟐(𝑹𝟏.𝑩=𝑹𝟐.𝑩) 
Boʼlish (/).
𝑹𝟏÷𝑹𝟐

Talaba: Tursunboyev O`rinboy Odilovich 
</pre>