                <h4>Create a new account</h4>
                <div class="box">
                <form action="register.php" method="post">
                    <p>User ID: <input type="text" name="userId" size="30"/>*</p>
                    <p>Password: <input type="password" name="password" size="30"/>*</p>
                    <p>Retype Password: <input type="password" name="repassword" size="30"/>*</p>
                    <p>First Name: <input type="text" name="firstName" size="30"/>*</p>
                    <p>Last Name: <input type="text" name="lastName" size="30"/>*</p>
                    <p>Your Address (*):</p>
                    <p> <textarea name="address" rows="5" cols="30"></textarea></p>
                    <p>Phone: <input type="text" name="phone" size="20"/>*</p>
                    <p>E-mail: <input type="text" name="email" size="21"/>*</p>
                    <p><input type="submit" value="Create Account"/></p>
                </form>
                </div>