<?php
require "sql_connection.php";
if(isset($_POST['submit']))
{
if($_GET["userId"]==$_GET["repassword"]){
mysql_query("insert into customer (userId, password, firstName, lastName, address,
phone, email) 
values
  ('$_GET[userId]','$_GET[password]','$_GET[firstName]','$_GET[lastName]','$_GET[address]','$_GET[phone]','$_GET[email]')")
or die(mysql_error());
}
echo "Done!!!!";
}
?>