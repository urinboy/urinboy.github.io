<?php
    $errors = array();
    if (isset($_POST['submit'])) {
        $first = $_POST['contact_first'];
        $last = $_POST['contact_last'];
        $email = $_POST['contact_email'];
        $subject = $_POST['subject'];
        $message = $_POST['message'];
        // tekshirish uchun
        if(empty($first) || empty($last) || empty($email) ) {
            $errors['contact_first'] = "Ismingizni kiriting!";
        }
        elseif(empty($last)) {
            $errors['contact_last'] = "Familiyangizni kiriting!";
        }
        elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = "Elektron pochta manzili yaroqsiz";
        }
        elseif(empty($email)) {
            $errors['email'] = "Elektron pochtani kiriting!";
        }
        elseif(empty($subject)) {
            $errors['subject'] = "Mavzuni kiriting!";
        }
        elseif(empty($subject)) {
            $errors['subject'] = "Xabarni kiriting!";
        }
        elseif(empty($message)) {
            $errors['message'] = "Xabarni kiriting!";
        } else {
            $to = "urinboytursunboev@gmail.com";
            if(mail($to,$subject,$message,$email)) {
                header("location: contact.php?success");
            }
        }
    } else {
        header("location: contact.php");
    }


    $page_id = '';
    $page_url = "/contact.php";
    $title = "Biz bilan bog'lanish";
    $site_name = "TUORMedia.uz";
    include "includes/header.php";
?>

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Biz bilan bog'lanish</h2>
        </div>

        <div class="row mt-1 d-flex justify-content-end" data-aos="fade-right" data-aos-delay="100">

          <div class="col-lg-5">
            <div class="info">
              <div class="address">
                <i class="icofont-google-map"></i>
                <h4>Manzil:</h4>
                <p>O'zbekiston, Qoraqalpog'iston Respublikasi, Taxiatosh tumani, Keneges OFY</p>
              </div>

              <div class="email">
                <i class="icofont-envelope"></i>
                <h4>Email:</h4>
                <p>urinboytursunboev@gmail.com</p>
              </div>

              <div class="phone">
                <i class="icofont-phone"></i>
                <h4>Tel:</h4>
                <p>+998 91 373 11 96</p>
              </div>

            </div>

          </div>

          <div class="col-lg-6 mt-5 mt-lg-0" data-aos="fade-left" data-aos-delay="100">

          <form action="contact.php" method="post" role="form" class="php-email-form">
             
          <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                 <?php foreach($errors as $error): ?>
                    <li style="list-style-type:none;">
                    <i class="bx bx-error-circle"> </i>    
                    <?php echo $error; ?></li>
                    <?php endforeach; ?>
                </div> 
                <?php endif; ?>
                <?php
                    $msg = "";
                    if (isset($_GET['success'])) {
                      $msg = 'Xabaringiz jo`natildi';
                        echo '<div class="alert alert-success"><i class="bx bx-success"> </i>'.$msg.' </div>';
                    }
                ?>
 
             <div class="form-row">
                  
                <div class="col-md-6 form-group">
                  <input type="text" name="contact_first" class="form-control" id="contact_first" value="<?php echo $first; ?>" placeholder="Ism"/>
                </div>
                <div class="col-md-6 form-group">
                  <input type="text" name="contact_last" class="form-control" id="contact_last" value="<?php echo $last; ?>" placeholder="Familiya" />
                </div>
                <div class="col-md-6 form-group">
                  <input type="email" class="form-control" name="contact_email" id="contact_email" value="<?php echo $email; ?>" placeholder="address@tuormedia.uz" />
                </div>
              
                <div class="col-md-6 form-group">
                    <input type="text" class="form-control" name="subject" id="subject" value="<?php echo $subject; ?>" placeholder="Mavzu" />
                </div>
                </div>
                <div class="form-group">
                    <textarea class="form-control mb-2" name="message" rows="8"  value="<?php echo $message; ?>"  placeholder="Xabar"></textarea>
                </div>
        <!-- <div class="mb-3">
                <div class="loading">Yuborilmoqda</div>
                <div class="error-message"></div>
                <div class="sent-message">Raxmat sizning xabaringiz yuborildi!</div> 
              </div> -->

              <div class="text-center"><button type="submit" name="submit">Xabarni yuborish</button></div>
            </form>

          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->


<?php include "includes/footer.php"; ?>