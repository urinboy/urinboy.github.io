
<!-- Vendor JS Files -->
<script src="styles/vendor/jquery/jquery.min.js"></script>
<script src="styles/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="styles/vendor/jquery.easing/jquery.easing.min.js"></script>
<script src="styles/vendor/php-email-form/validate.js"></script>
<script src="styles/vendor/owl.carousel/owl.carousel.min.js"></script>
<script src="styles/vendor/venobox/venobox.min.js"></script>
<script src="styles/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script src="styles/vendor/aos/aos.js"></script>

<!-- Template Main JS File -->
<script src="styles/js/main.js"></script>
