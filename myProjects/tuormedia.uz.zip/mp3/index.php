    <!-- ======= Team Section ======= -->
    <section id="team" class="team section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>$CATEGORY_NAME$</h2>
          <p></p>
        </div>

        <div class="row">

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
            <div class="member d-flex align-items-start">
            <div class="pic">
                <!--IMG1-->
                <a href="$IMG_URL1$" class="ulightbox" target="_blank" title="Ko'rish uchun shu yerga bosing">
                    <img alt="" style="margin:0;padding:0;border:0;width:100px;height:100px;border-radius: 6px;" src="$IMG_URL1$" align="">
                 </a>
                <!--IMG1-->
            </div>
              <div class="member-info">
                <h4><a href="$ENTRY_URL$"><h2>$TITLE$</h2></a></h4>
                <span><a href="$CATEGORY_URL$">$CATEGORY_NAME$</a></span>
                <div class="btn-wrap">
              <a href="#" class="btn-buy"> Yuklash</a>
              </div>
              </div>
            </div>
          </div>


        </div>

      </div>
    </section><!-- End Team Section -->
