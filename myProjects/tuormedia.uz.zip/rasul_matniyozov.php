<?php
$page_id = '';
$page_lang = "uz";
$url = "http://tuormedia.uz/rasul_matniyozov.php";
$category = "Sheriyat";
$title = "Matniyozov Rasulbek Gulmirza o'g'li";
$site_name = "TUORMedia.uz";
$description = "Matniyozov Rasulbek She'rlari";
$keywords = " Matniyozov Rasulbek Sherlari, tuormedia.uz, She'riyat, Rasulbek, Matniyozov, Shoir, ijodkor 2020";
$local = "Amudaryo, Do`man OFY";
$image = "http://tuormedia.uz/styles/img/portfolio/rm.jpg";
include "includes/header.php";
?>
    <!-- ======= Portfolio Details Section ======= -->
    <section id="portfolio-details" class="portfolio-details">
      <div class="container">
        <div class="portfolio-details-container">
          <div class="owl-carousel portfolio-details-carousel">
            <img src="/styles/img/portfolio/rm.jpg" class="img-fluid" alt="">
            <img src="/styles/img/portfolio/rm-2.jpg" class="img-fluid" alt="">
            <img src="/styles/img/portfolio/rm-3.jpg" class="img-fluid" alt="">
            <img src="/styles/img/portfolio/rm-4.jpg" class="img-fluid" alt="">
            <img src="/styles/img/portfolio/rm-5.jpg" class="img-fluid" alt="">
            <img src="/styles/img/portfolio/rm-6.jpg" class="img-fluid" alt="">
          </div>
          <div class="portfolio-info">
            <h3>Loyiha ishtirokchisi haqida</h3>
            <ul>
              <li><strong>Bo'lim</strong>: She'rlar</li>
              <li><strong>Shoir</strong>: Matniyozov Rasulbek Gulmirza o'g'li</li>
              <li><strong>Tug'ilgan sanasi</strong>: 12-yanvar, 1998 yil</li>
              <li><strong>Loyiha manzili URL</strong>: <a href="/">tuormedia.uz</a></li>
              <li><strong>Telegram Profili</strong>: <a href="https://t.me/Rasulbek_Matniyozov" class="twitter"><i class="bx bxl-telegram"></i> @Rasulbek_Matniyozov</a></li>
            </ul>
          </div>

        </div>

        <div class="portfolio-description">
          
    <!-- ======= Frequently Asked Questions Section ======= -->
    <section id="faq" class="faq section-bg">
      <div class="container" data-aos="fade-up">

      <div class="section-title">
          <h2>Shoir Ijodidan</h2>
          <p></p>
        </div>

        <div class="faq-list">
          <ul>
            <li data-aos="fade-up" data-aos="fade-up" data-aos-delay="100">
              <i class="bx bxs-user-detail icon-help"></i> <a data-toggle="collapse" class="collapse" href="#faq-list-1">

              Farishta yoki malak

 <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-1" class="collapse show" data-parent=".faq-list">
                <p>
<pre>

Sahar shabnam yuvgan go’yo yuzlaringni 
Bo’lsam deyman kipriklari ko’zlaringni
Sen jumboqsan yecholmagan yuragim
Kelar har kun suratinga qaragim

Qalbimda bahorlar shamoli yelar 
Bilmadim qabimngda bordir nelar 
Sendan izlaganim dunyolar emas 
Bir bora kulib qo’y menga yetar bas

Tonglar otmas o’ylab visoling shirin
Bu go’zal nigohda nelar yashirin 
Yuragimda saqlab shirin tuyg’uni 
Qora ko’zlaringni bo’ldim maftuni

Shamollar silaydi sochlaring mayin
Yuragim talpinar senga kun sayin 
Kulganingda olam nurga cho’milar 
Kulgichlaring bilmam demoqchi nelar

Bog’imdagi gullar senga poyondoz 
Shirin tabassuming o’zinga pardoz
Har kuni o’ylanib o’ylarim xalak
Farishtamisan sen yoki bir malak!!

</pre>                </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="200">
              <i class="bx bxs-user-detail icon-help"></i> <a data-toggle="collapse" href="#faq-list-2" class="collapsed">
               
              Muhabbat qissasi 
               
               <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-2" class="collapse" data-parent=".faq-list">
                <p>
<pre>

O’tgan ekan go’zal pari gulruxsor
Oshiqlari ekan yo’llarida zor
Shamollar silarkan uzun sochlarin
Kuylarkan shoirlar kamon qoshlarin

Ko’zlariga ohu xasad qilarkan
Majnunlar visolin orzu qilarkan
Yurganida asta sekin noz bilan
Yigitlar ishqida ado bo’larkan

Hammani bir savol rossa qiynarkan
O’shal pari kimni?, kimni o’ylarkan
O’tibdi bahorlar,  necha yozu-kuz
Ne uchundur go’zal bunchalar mayus

Shahlo ko’zlari bo’libon masum
Lablarin tark etgandi tabassum
Hech kimga aytmasdi qalbdagi sirin
Bu mayus nigohda nelar yashirin

U kutar yorin urushga ketgan
Hayollarin esa mangu band etgan
Eslardi yigitning shirin so’zlarin
Muhabbatga to’la qora ko’zlarin

Yigit ham sevardi qizni jonidan
Jilgisi kelmasdi uning yonidan
Ishonmasdi qizni yer-u ko’klarga
Lek nishon bo’lgandi qora o’qlarga

Ketayotib aytgandi shu so’zlarni
Kutgin qaytaman yengib yovlarni
Yigit jo’nab ketdi urush yo’liga
Janga kirdi ushlab qurol qo’liga

Atrofni qoplabon misoli zulmat
Yigitdan keldi bir kun qora xat
Ko’zlaridan oqib marjon-marjon yosh
Qiz zor yig’lardi qilolmay bardosh

Bu gaplarga u ishonolmasdi
Chunki yorisiz qiz yasholmasdi
Hayot ko’rinardi ko’zlariga tor
Armon edi quchmoq uni so’nggi bor

Lekin qiz yashardi yuragi pora
Kutardi qaytishin kelar deb zora
Yuzlari so’lardi boshida kulfat
Shunchalik bo’larmi yorga muhabbat

Vaqt o’tardi tez qilib bilganin
Qiz esa tan olmas yigit o’lganin
Qalbini o’rtar xotiralar shirin
Yuragida saqlab yigit tasvirin

Umri o’tib borar o’tardi yoshi
Yigit bergan ro’mol uning sirdoshi
Qalbida umidlar so’nar tobora
Uxlaydi tushimga kirar deb zora

Qilgan duolari xudoga yetdi
Ne ajabki yori urushdan qaytdi
Yigit quchog’iga qiz o’zin otdi
Ko’zlarida sevinch yoshlari oqdi

Qiz quchar yigitni ko’zlarida yosh
Go’yoki porlardi qalbida quyosh
Yuraklardan o’chib hijron izlari
Bir-biriga qarab to’ymas ko’zlari

Sog’inch qiynamasdi ularni ortiq
Baxtlarini xudo etgandi tortiq
Nelar bo’lmas deysiz bu keng olamda
Ishonch bo’lsa yetar yolg’iz odamda

Baxtiga yetadi shubhasiz inson
Hattoki bo’lsa ham yori deb xazon
Faqat so’nmasa bas yurakda tug’yon
Qolgani esa o’zi bo’ladi ayon

Sizlarga so’zladim men bir hikoya
Endi qo’ymoq kerak unga nihoya
Sevib yonib yashang g’aflatdan yiroq
Vaqti keldi endi  uni tugatmoq.

</pre>              </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="300">
              <i class="bx bxs-user-detail icon-help"></i> <a data-toggle="collapse" href="#faq-list-3" class="collapsed"> 
              
              Sen kulganda  
              
              <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-3" class="collapse" data-parent=".faq-list">
                <p>
                  <pre>

Sen kulganda olam yashnar
Agar boqsam ko’zim qamashar
Charos ko’zing yulduzga o’xshar
Ko’nglimga o’t yoqqan qiz

Yeta olmay menman xalak
Faqat sen deb urar yurak
Orzuimsan ,sen shirin tilak
Qalbimda bahor bo’lgan qiz

Ko’rgim kelar sensan olis
Ishon menga so’zim xolis
Aytgim kelar shuni bir og’iz
Yuragimga joylangan qiz

Qadam bosarsan dona-dona
Sensiz yurak bo’lur g’amxona
Gaplashgani izlarman bahona
Ushbu she’rim atalgan qiz
</pre>              </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="400">
              <i class="bx bxs-user-detail icon-help"></i> <a data-toggle="collapse" href="#faq-list-4" class="collapsed">
              
              Sohibjamol

 <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-4" class="collapse" data-parent=".faq-list">
                <p><pre>

Gulday go’zal nigohing o’g’irladi xayolim
Nega buncha go’zalsan javobsizda savolim
Lablaringa qiyosdir atirgulni g’unchasi
Bilmam senga shaydodir yigitlarni qanchasi

Qo’ng’iroqdek ovozing daryodayin toshasan
Bilmadim sohibjamol sen qaylarga shoshasan
Shirin tabassumlaring hayajonga soladi
Bu ertakning oxiri qanday tamom bo’ladi?
</pre>
              </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="500">
              <i class="bx bxs-user-detail icon-help"></i> <a data-toggle="collapse" href="#faq-list-5" class="collapsed">
              
              Go’zal yor
              
              <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-5" class="collapse" data-parent=".faq-list">
                <p>
                <pre>
                
Qo’llaringa gul tutsam olarmisan go’zal yor
Har kun kelar deb kutsam kelarmisan ey dildor
Bedor bo’lsam tunlari vaslingni umidida
Qanchalik sog’inganim bilarmisan ey gulyor

Baxt tomon chorlasam ketarmisan go’zal yor
Qo’linga qo’lim cho’zsam tutarmisan ey dildor
Dardlarim oshkor etsam ko’zlaringa termulib
Muhabbatimni qabul etarmisan ey gulyor

              </p>
              </div>
            </li>
 <li data-aos="fade-up" data-aos-delay="600">
              <i class="bx bxs-user-detail icon-help"></i> <a data-toggle="collapse" href="#faq-list-6" class="collapsed">

              Qizlar shunday …

<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-6" class="collapse" data-parent=".faq-list">
                <p>
                <pre>


Bir so’z desangiz uyalib tursa
Noz-karashma bilan asta yursa
Sizni ko’rganda labini bursa
Bilingki qizlar shunday bo’ladi

Gohida kulib , gohi yig’lasa
Goh quvontirib , gohi qiynasa
Gohida sizni yomon boplasa
Bilingki qizlar shunday bo’ladi

Gap- so’zlarga quloq solmasa
Shirin so’zlariga sizni bog’lasa
Bir gapni izidan sira qolmasa
Bilingki qizlar shunday bo’ladi

Chaqirsangiz u siz tomon boqsa
Gohida so’zlari yurakka botsa
Agar o’sha qiz sizgayam yoqsa
Bilingki qizlar shunaqa bo’ladi

Doyimo kulib ajib yashasa
O’zgalar bilan hech gaplashmasa
Instagramdan sira chiqmasa
Bilingki qizlar shunday bo’ladi

Yomon so’zlarni tilga olmasa
Ko’zlari doim kulib porlasa
Maktubingizga javob yozmasa
Bilingki qizlar shunday bo’ladi

Bazida ko’zin qoshin bo’yasa
Gohida yolg’on rosin so’ylasa
Yigitim bor deb sizni aldasa
Bilingki qizlar shunday bo’ladi

Har kuni har xil libosda bo’lsa
O’z hayotidan ko’ngli to’lsa
Jahli chiqqanda tashlanib qolsa
Bilingki qizlar shunday bo’ladi

Chin muhabbatin dilda saqlasa
Ota-onasin ishonchin oqlasa
Bu gaplarimdan foyda chiqmasa
Bilingki qizlar shunday bo’ladi

</pre>
</p>
              </div>
            </li>
<li data-aos="fade-up" data-aos-delay="700">
              <i class="bx bxs-user-detail icon-help"></i> <a data-toggle="collapse" href="#faq-list-7" class="collapsed">

              Oyimqiz

<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-7" class="collapse" data-parent=".faq-list">
                <p>
                <pre>

Sensan qalbimda ochilgan chechak
Isxorim aytolmay menman xalak
Hayajonga to’lar ko’rganda yurak
Hayollarim senda oyimqiz

Balki ishonishmas mening so’zimga
Barchadan a’losan mening ko’zimga
Dardlaring bergin olay o’zimga
Mayli bemor o’zim bo’layin

Sen kulganda porlagay quyosh
Gohida sog’insam surating sirdosh
Hayot yo’llarida bo’laylik yo’ldosh
Qo’llaring bergin qo’limga

</pre>
</p>
              </div>
            </li>

<li data-aos="fade-up" data-aos-delay="800">
              <i class="bx bxs-user-detail icon-help"></i> <a data-toggle="collapse" href="#faq-list-8" class="collapsed">

              Oshig’ingman

<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-8" class="collapse" data-parent=".faq-list">
                <p>
                <pre>

Jamoling tariflab ovvora qalam
Dardlarim shifosi o’zingsan sanam
Baxtli davom etsin bizning ertak
Baxt-u shodlikni ko’raylik baham

Qiynama oshig’ing ko’yingda bedor
Rahim qilgin o’zing unga bir bor
Yuragimni qiynar birgina savol
Oshig’ligim senga kelmasmu malol

</pre>
</p>
              </div>
            </li>


<!-- <li data-aos="fade-up" data-aos-delay="900">
              <i class="bx bxs-user-detail icon-help"></i> <a data-toggle="collapse" href="#faq-list-9" class="collapsed">



<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-9" class="collapse" data-parent=".faq-list">
                <p>
                <pre>


</pre>
</p>
              </div>
            </li> -->


          </ul>
        </div>

      </div>
    </section> <!-- End Frequently Asked Questions Section -->

        </div>
<!-- End Portfolio Details Section -->

<?php include "includes/footer.php"; ?>