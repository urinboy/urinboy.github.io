<?php

$token = '1741576096:AAGN5rgcCN1r2TnahvuDZr4hNL4S_DHB1io';

function bot($method,$datas=[]){
global $token;
    $url = "https://api.telegram.org/bot".$token."/".$method;
    $tgcurl = curl_init();
    curl_setopt($tgcurl,CURLOPT_URL,$url);
    curl_setopt($tgcurl,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($tgcurl,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($tgcurl);
    if(curl_error($ch)){
        var_dump(curl_error($tgcurl));
    }else{
        return json_decode($res);
    }}

//baza bilan ulanish joyi

$connect = mysqli_connect('localhost', 'tuormedia_news', 'Salom@1196','tuormedia_news');
mysqli_set_charset($connect, "utf8mb4");


/*
*$users = "CREATE TABLE users(
*user_id int(15),
*name varchar(50))";
*mysqli_query($connect, $users);
*/


$teleApi = json_decode(file_get_contents('php://input'));
$coder = $teleApi->message;
$cid = $coder->chat->id;
$text = $coder->text;

/*
if(strpos($text, "/start") === 0) {
 $response = "Ciao $firstname, benvenuto!"; $keyboard = [
 'inline_keyboard' => [ [ ['text' => 'forward me to groups'] ] ] ]; 
$encodedKeyboard = json_encode($keyboard); $parameters = array( 'chat_id' => $chatId, 'text' => $response, 'reply_markup' => $encodedKeyboard ); $parameters["method"] = "sendMessage"; echo json_encode($parameters); }
/////////////

$keyboard = [ 'inline_keyboard' => [ [ ['text' => 'forward me to groups', 'callback_data' => 'someString'] ] ] ]; $encodedKeyboard = json_encode($keyboard); $parameters = array( 'chat_id' => $chatId, 'text' => $response, 'reply_markup' => $encodedKeyboard ); send('sendMessage', $parameters); // function description Below
*/



public function inlineKeyword($chat_id, $keyword_data, $msg = '') { if (empty($msg)) { $msg = "Select"; } $inline_keyboard = array(); $row = 0; $prev_value = ''; foreach ($keyword_data as $value) { if (isset($prev_value['text']) && strlen($prev_value['text']) < 10 && strlen($value['text']) < 10) { $inline_keyboard[$row - 1][] = $value; } else { $inline_keyboard[$row][] = $value; } $prev_value = $value; $row++; } // $inline_keyboard[] = $keyword_data; $reply_markup = $this->telegram->replyKeyboardMarkup([ 'inline_keyboard' => $inline_keyboard, 'resize_keyboard' => true ]); $response = $this->telegram->sendMessage([ 'text' => $msg, 'reply_markup' => $reply_markup, 'chat_id' => $chat_id ]); }


// bazani tekshirish xalos
if($text=="/start"){
if($connect){
//ulanish true qaytsa
bot('sendMessage',[
  'chat_id'=>$cid,
  'text'=>"✅Mysql botga ulangan",
  ]);
}else{
//ulanish false qayganda
bot('sendMessage',[
  'chat_id'=>$cid,
  'text'=>"❌Mysql botga ulanmagan",
  ]);
}
}
/*
if(mb_stripos($text,"/text=")!==false){
$exp = explode("=",$text)[1];
$sql = mysqli_query($connect, "INSERT INTO users(user_id,name,username) VALUES ('$cid','$exp','@tuormedia')");
if($sql){
$result = mysqli_query($connect,"SELECT * FROM users WHERE name = $exp");
$row = mysqli_fetch_assoc($result);
$id = $row['user_id'];
$name = $row['name'];
$user = $row['username'];
if($row){
bot('sendMessage',[
  'chat_id'=>$cid,
  'text'=>"$id
$name
$user",
  ]);
}else{
bot('sendMessage',[
  'chat_id'=>$cid,
  'text'=>"$exp bazada topilmadi",
  ]);
}
}else{
bot('sendMessage',[
  'chat_id'=>$cid,
  'text'=>"❌Mysql Xatolik bor",
  ]);
}
}*/

?>