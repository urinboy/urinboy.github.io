<?php
session_start();

if(isset($_SESSION['id']) && isset($_SESSION['user_name'])){

?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Foydalanuvchi sahifasi</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Salom, <?php echo $_SESSION['name']; ?></h1><br>
<?php
 echo "Bugun: ".date("d-m-Y")."<br>";
 echo "Haftaning ".date("l")." kuni <br>";
 echo "Soat ".date("h:i");
 ?>
<br>
<a href="logout.php">Chiqish</a>
</body>
</html>

<?php
}else{
    header("Location: index.php");
    exit();
}
?>