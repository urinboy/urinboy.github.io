<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Sign Up - TUORMedia.uz</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="TUORMedia.uz, tuormedia Tursunboyev Urinboy" name="keywords">
    <meta content="TUORMedia.uz" name="description">
<?php include 'http://tuormedia.uz/partial/head.php'; ?>
</head>
<body id="body">
    <?php include 'http://tuormedia.uz/partial/navs.php'; ?>
<main id="main">
Sahifa


    </main>
<?php include 'partial/foot.php'; ?>
   
</body>

</html>
