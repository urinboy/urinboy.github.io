<?php

$sname = "sql307.epizy.com";
$uname = "epiz_26171406";
$password = "7N1mkBO2anN";

$db_name = "epiz_26171406_99";

$conn = mysqli_connect($sname, $uname, $password, $db_name);

if(!$conn){
    echo "Ulanish amalga oshmadi!";
}
?>
<link rel="stylesheet" href="style.css">
