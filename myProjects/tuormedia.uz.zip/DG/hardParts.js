const person = new Object({
    name: "Muikhammadyusuf Abdurakhimov",
    age: 18,
    buy: 20000,
    getCoffe: function (){
        console.log("I got coffee")
    }
})

Object.size = function(obj) {
    var size = 0, key;
    for (key in obj) {
        if (obj.hasOwnProperty(key)) size++;
    }
    return size;
};
let size = Object.size(person)
let kerakli = Object.keys(person)
for(let i = 0; i < size; i++ ){
    console.log(kerakli[i]+ ": " + person[kerakli[i]]);
}

for (key in person){
    console.log(key + ": " + person[key])
}