/*
* Part 2
* Author: Mukhammadyusuf Abdurakhimov
* Company: Digital Generation Uzbekistan
* */

let person = {
    name: "Mukhammadyusuf",
    age: 18,
    eyeColor: "green"
}

let odamlar = [
    {
        name: "Mukhammadyusuf",
        age: 18,
        buys: 2000
    },
    {
        name: "Shahina",
        age: 14,
        buys: 5100
    },
    {
        name: "Alan",
        age: 21,
        buys: 10000
    },
    {
        name: "Davron Kabulov",
        age: 29,
        buys: 55000
    }
]

let objects = document.querySelector(".objects")

for (let i = 0; i < odamlar.length; i++){
    objects.innerHTML += "<div class='item'><p>Name: <b>" +
        odamlar[i].name + "</b><br>Age: " + odamlar[i].age +
        "<br>Buys: " + odamlar[i].buys +
        "</p> <button>View Profile</button> </div>"
}

let search = document.querySelector("#search")

search.addEventListener("input", function(){
    let toSearch = search.value
    //
    // for(var i=0; i<odamlar.length; i++) {
    //     var results = []
    //     for(key in odamlar[i]) {
    //         if(odamlar[i][key].indexOf(toSearch)!=-1) {
    //             results.push(odamlar[i]);
    //         }
    //     }
    // }
    console.log(toSearch)
})