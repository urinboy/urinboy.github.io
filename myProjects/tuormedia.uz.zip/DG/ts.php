<?php
$a = fgets(STDIN);
$b = explode(" ", $a);
echo "$b";
?>