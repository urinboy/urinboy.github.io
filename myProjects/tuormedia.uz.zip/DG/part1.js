/*
* Author: Mukhammadyusuf Abdurakhimov
* Place: Digital Generation Uzbekistan
* Part 1
* */

let a = prompt("Kasbingizni kiriting kiriting: ")
let b = confirm(a + " siz 18 yoshga to'lganmisiz?")

//if else statements
if(b){
    alert("Cool")
}else{
    alert("Ooops")
}
if(a == "Matematik" || a == "Matematika o'qituvchisi"){
    alert("Haha, siz Nobel mukofoti ola olmaysiz!")
}
//switch case
let caseCha = prompt("Son kiriting")
switch(caseCha){
    case "1":
        alert("Haftaning " + caseCha + "-kuni Dushanba")
        break;
    case "2":
        alert("Haftaning " + caseCha + "-kuni Seshanba")
        break;
    default:
        alert("Haftada " + caseCha + "-kun mavjud emas!!!")
}

//for loop
for(let i=0; i<10; i++){
    console.log("Assalomu alaykum")
}
for (let i=10, d=20; i<100 || d==20; d++, i++){

}

//while
let aa = 1
while(aa<10){
    console.log("Hey," + aa)
    aa++
}

//do while
do{
    console.log(1)
}while(false)

//matematika
// / * - + %

//functions

function printArrrayElements(cars){
    for (let i = 0; i < cars.length; i++){
        console.log(cars[i])
    }
}
let elementsToPrint = ["Ford", "Volvo", "BMW", "Ferrari", "Masseratti"]

printArrrayElements(elementsToPrint);


function sayHello(name){
        if (name == "Dilbek"){
            return "Hey"
        }else if(name == "Mukhammadyusuf"){
            return "Hello"
        }
    return "Salom"
}
let davr = 10;
console.log(sayHello("Dilbek"))
console.log(davr)
