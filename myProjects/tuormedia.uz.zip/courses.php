<?php
$page_id = '';
$page_url = "/courses.php";
$title = "Kurslar";
$site_name = "TUORMedia.uz";
include "includes/header.php";
?>
    <!-- ======= Services Section ======= -->
    <section id="services" class="services" style="margin-top:-120px">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Kurslar</h2>
          <p></p>
        </div>

        <div class="row">
          <div class="col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
            <div class="icon-box">
              <i class="icofont-computer"></i>
              <h4><a href="#">Kompyuter savodxonligi kursi</a></h4>
              <p>Texnologiyalar olamiga xush kelibsiz. Sizga bu kursda kompyuter haqida barcha ma'lumotlarni bilib olasiz.</p>
            </div>
          </div>
          <div class="col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="fade-up" data-aos-delay="600">
            <div class="icon-box">
            <i class="bx bxl-google"></i>
              <h4><a href="#"> Google platformasi haqida kurs</a></h4>
              <p>Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi</p>
            </div>
          </div>
          <div class="col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="fade-up" data-aos-delay="200">
            <div class="icon-box">
            <i class="bx bxl-windows"></i>
              <h4><a href="#">MicroSoft Office dasturlari kursi</a></h4>
              <p>MicroSoft Office dasturlari Word, Exsel, PowerPoin va boshqa dasturlari haqida siz shu kursuimizda bilib olasiz.</p>
            </div>
          </div>
          <div class="col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="fade-up" data-aos-delay="300">
            <div class="icon-box">
            <i class="bx bxl-html5"></i>
              <h4><a href="#"> HTML 5 boshlang'ich kursi</a></h4>
              <p>Saytlar yaratishni istasangiz siz avvalo saytning asos ya'ni suyak qismi bo'lmish HTML shu kursimizda bilib oilishingiz mumkin. </p>
            </div>
          </div>
          <div class="col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="fade-up" data-aos-delay="400">
            <div class="icon-box">
            <i class="bx bxl-css3"></i>
              <h4><a href="#"> CSS 3 boshlang'ich kursi</a></h4>
              <p>Saytning tashqi ko'rinishini CSS kodlari orqali ishlashni shu kursimizda bilib olasiz.</p>
            </div>
          </div>
          
          <div class="col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="fade-up" data-aos-delay="500">
            <div class="icon-box">
            <i class="bx bxl-javascript"></i>
              <h4><a href="#"> Javasrcipt boshlang'ich kursi</a></h4>
              <p>Jonli sayt uchun Javascript kursimizga yoziling va ajoyib narsalarni o'rganing</p>
            </div>
          </div>
          <div class="col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="fade-up" data-aos-delay="600">
            <div class="icon-box">
            <i class="bx bxl-bootstrap"></i>
              <h4><a href="#"> Bootstrap boshlang'ich kursi</a></h4>
              <p>Css kodlarni yozish xatolar ko'payib ketsa asablarni asrang va tayyor css ko;dlaridan foydalaning. Ushbu kursada siz shunday imkoniyatlar bilan tanishasiz.</p>
            </div>
          </div>
          
          <div class="col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="fade-up" data-aos-delay="600">
            <div class="icon-box">
            <i class="bx bxl-wordpress"></i>
              <h4><a href="#"> WordPress boshlang'ich kursi</a></h4>
              <p>Endi saytlarni yanada tez va mukammal yaratish mumkin. Bu imkoniyat Wordpress CMS da mavjud. Ushbu kursda siz Wordpresni o'rganasiz.</p>
            </div>
          </div>
          <div class="col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="fade-up" data-aos-delay="600">
            <div class="icon-box">
            <i class="icofont-evernote"></i>
              <h4><a href="#"> PHP boshlang'ich kursi</a></h4>
              <p>PHP ni o'rganing va yana bir qadam oldinga oldinga chiqing. Sizning sahifalaringiz endilikda Dinamik bo'lishi uchun ushbu kursimini a'zsiga aylaning.</p>
            </div>
          </div>
          
          <div class="col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="fade-up" data-aos-delay="600">
            <div class="icon-box">
            <i class="bx bxl-python"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAkCAYAAADhAJiYAAACIElEQVRYhe3Xr3MaQRQH8BURyIoKRAUCEVGBqKj87puIioiI/gEREZERERGIm0FERPQPqEBUVCLS95aoE5ERERWRCNi3DBUVFQjERUCnGYa7Wzp3xPBm3gwzzMDn3o9dMGYf+3ilmDGaQfBZmc49U+KZEmWcqeBkNMCbnUGU8UnFPqjYrDhpMB6iXStmPERbxS5U7C911q1eF8FCrdXyTImKzfwQR8YYo46+RlTqon6Q4Gb6A+9V7GMZyDMltYO2yVpBwQF/N2o9dwKaMDrqqJuHiAWpoysVm3qhW3XU3XrQsxQHQej7tu3JA3mm/vr2BYdWNEgZvSowBaBMhQbR1VGxf6oCqdDFZpDNolrnhziqDmMzvcPh6hDd8D5OSkHB4bQyDKM3YzRV7DyveuXz46hb8kVzFRp4wU3exgWhywmjMxG8U7ZPRfMVA7rKf2L7NGM0lfFBGT3P1M9LFXufX5ktQAUtW4yHaCvjusqBjwEh5wPug0OryoGfMo5LQaMUjU2l9kx9ZTqvEDQfpWiUgowxRgVfNoH+53LNn0dcR2GMMUZv8XZ9OyoFMX3LUhxEg/61bnnKLtuFsyJQcDiNSb3D4VaQoii51XPWP+I0rgNUAE1eG/QzOLSC0GXtoLi1X/6smAo+1g4apWgU3U0v8kHF/laxiwmjUxvImOU/1tVdVXhPqdjH4IBaMS9jlKIRHLC+1lPG8YzR3BlkH/tYi2fzP8kIuoAC0gAAAABJRU5ErkJggg=="/></i>
              <h4><a href="#"> Python boshlang'ich kursi</a></h4>
              <p>Python orqali universallik sari olg'a. Veb dasturlash kompyuterlarlar uchun dasturlar, mobil qurilmalar uchun ilovalarni yaratishda keng imkoniyatlarni sizga Python dasturlash tili beradi. Biz bilan Pythonni o'rganib o'z loyihalaringizni mukammal darajaga yetkazing.</p>
            </div>
          </div>
        </div>
      </div>
    </section><!-- End Services Section -->
    <?php
    include "includes/footer.php";
    ?>