<?php
$page_id = '';
$category = "Sheriyat";
$title = "Jasurbek Tajibayev Saatbayevich";
$site_name = "TUORMedia.uz";
include "includes/header.php";
?>
    <!-- ======= Portfolio Details Section ======= -->
    <section id="portfolio-details" class="portfolio-details">
      <div class="container">
        <div class="portfolio-details-container">
          <div class="owl-carousel portfolio-details-carousel">
            <img src="styles/img/portfolio/shoir-1.jpg" class="img-fluid" alt="">
            <img src="styles/img/portfolio/shoir-2.jpg" class="img-fluid" alt="">
            <img src="styles/img/portfolio/shoir-3.jpg" class="img-fluid" alt="">
          </div>
          <div class="portfolio-info">
            <h3>Loyiha ishtirokchisi haqida</h3>
            <ul>
              <li><strong>Bo'lim</strong>: She'rlar</li>
              <li><strong>Shoir</strong>: Jasur Tajibayev Saatbayevich</li>
              <li><strong>Tug'ilgan sanasi</strong>: 10-May, 2003 yil</li>
              <li><strong>Loyiha manzili URL</strong>: <a href="/">tuormedia.uz</a></li>
              <li><strong>Telegram Profili</strong>: <a href="https://t.me/JasurbekSaatbayevich" class="twitter"><i class="bx bxl-telegram"></i> @JasurbekSaatbayevich</a></li>
              <li><strong>Telegram Profili</strong>: <a href="https://t.me/Taxiyatoshim" class="twitter"><i class="bx bxl-telegram"></i> @taxiyatoshim</a></li>
            </ul>
          </div>

        </div>

        <div class="portfolio-description">
          
    <!-- ======= Frequently Asked Questions Section ======= -->
    <section id="faq" class="faq section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title" style="text-align:center; margin: auto;">
          <h2 class="text-center">Shoirimizning ijod maxsuli</h2>
        </div>

        <div class="faq-list">
          <ul>
            <li data-aos="fade-up" data-aos="fade-up" data-aos-delay="100">
              <i class="bx bxs-user-detail icon-help"></i> <a data-toggle="collapse" class="collapse" href="#faq-list-1">

 TUG'ILISH...

 <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-1" class="collapse show" data-parent=".faq-list">
                <p>
<pre>

Qiziq bu hayotning ajab ishlari,
Dunyoga kelganda ichiga sig'mas.
Lekin bor ekanda yozning qishlari,
Og'ir judolikdan dunyoga sig'mas.

Shodlikdan suyunib chalingan sozlar,
Go'dak tug'ilgandan quvonar edi.
Har tomonni olgan yig'i ovozlar,
Suratingga qarab ovunar endi.

Qulog'ingga aytgan so'fi ozoni,
Umring so'ngigacha davim etadi.
Yolg'onchi hayotning shamol to'zoni, 
Poyonda janoza bilan eltadi.

Tug'ilganlik haqidagi guvohnomani, 
Kimdir tosh bitikka almashdi qo'ydi.
Unga ham yozdi lek biror nomani,
Ism familiyangni mahkamlab o'ydi.

 Senda edi oqlik poklikning ramzi,
Hali ulgurmagan hech bir hatoga.
Endi achchiq bo'lar ta'rif-u fusni,
Yana o'ralgaydir oppoq matoga.

Tiriklikda eslar o'z isming bilan,
Cheksizday edi-ku qisqami osmon.
Eslaydi ismingni ko'zda yosh bilan,
Faqatgina o'qir haqqinga "qur'on".
</pre>                </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="200">
              <i class="bx bxs-user-detail icon-help"></i> <a data-toggle="collapse" href="#faq-list-2" class="collapsed"> OTAM <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-2" class="collapse" data-parent=".faq-list">
                <p>
<pre>

Ishim yurmaganda tasalli bergan,
Hech kim qolmaganda yonimda turgan.
Yomonim yashirib òglim bor degan,
Dunyoda sizdayin inson yòq otam.

Begona gapiga pilaging buzma degan,
Ma'qul ishingni qil umiding uzma degan.
Hech qachon nomarga qòl sòzma degan,
Har gavhardan ortiq madanim otam.

Har qanday ishimni quvatlab qòllab,
Ollohdan baxtimni chin dildan sòrab.
Quvonsam quvonib qayģursam yiģlab,
Dardimni aytishga sirdoshim otam.

Kòp narsalar òrgamdim, boqiy hayot yòlingizdan,
Tabib ham mohir oshpaz ovqat yedim qòlingizdan.
Nelar orzu qilayapsiz umid qanday òģlingizdan,
Egnimdagi baxt qushim boshimda tojim otam.

Kòp yillardan buyon ota meni qiynar shu savol,
Ayni ushbu jumboqqa javob topish amri mahol.
Ota-ona òn farzandni oq yuvib oq taraydi,
O'nta bola otaning kònglin topolmay behol.
</pre>              </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="300">
              <i class="bx bxs-user-detail icon-help"></i> <a data-toggle="collapse" href="#faq-list-3" class="collapsed"> BAXT ÒZI NIMADIR? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-3" class="collapse" data-parent=".faq-list">
                <p>
                  <pre>

Hoy-havas kòyoda jon fido qilgan,
Boylikni eng oliy mudao qilgan.
Faqirni shoh vale shohni gado qilgan,
Baxt òzi nimada bilolmadim man?!

Husn tarovatga kimlar intilmas,
Zeb ziynatlar taqib naqshin keltirmas.
Gòzallik nimada farqini bilmas,
Baxt hissi nimada tuyolmadim man?!

Tongda yaqinlaring kulgusin kòrsang,
Shukr aytib qòlingni kòksinga ursang.
Asl baxt shundadir mendan sòrasang,
Yaqinlar oldida turganimiz baxt.

Hayot uzoq erur yòli nurafshon,
Ğalabamiz bisyor yordir sharaf shon.
Umr kòlankadir cheksiz bir oshyon,
Bu yoruģ olamni kòrganimiz baxt.

Vaqti, tilga kiring sòylang bobolar,
Baxtga tarif aylang bering baholar.
Eng baxtli insonlar kimdor daholar,
Baxtli kishi kimdir bilolmadim man.

Bu yoruģ olamni kòz bilan kòrish,
Baxt shudir farzandning tòyini kòrish.
Kuchga tòlgan soģlom bòyini kòrish,
Shundan ortiq baxt bormi foniy dunyoda.
</pre>              </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="400">
              <i class="bx bxs-user-detail icon-help"></i> <a data-toggle="collapse" href="#faq-list-4" class="collapsed">ZOYE KETGAN FURSAT QAYG'USI.
 <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-4" class="collapse" data-parent=".faq-list">
                <p><pre>

Hayot ko'chalari shamol izg'irin,
O'zni shu ko'chadan izlab qolaman.
Umr davom etar avjida qizg'in,
Bir fursat orqaga nazar solaman.
           * * *         
O'tdi qancha oylar yillar to'zoni,
O'tkazdik ko'p vaqtni huda behuda.
Sukutdan boshlanar ko'ngil isyoni, 
Vaqtni qaytarishni istayman juda.
          * * *
Ko'p vaqtim bekorga ketib qolibdi,
Zamon va o'zimga nazar solmabman.
Yosh ham o'n yettiga yetib qolibdi, 
Hayot darslaridan ta'lim olmabman.
          * * *
To'gri o'n yetti yosh qarilik emas,
Ayni gullab turgan yigitlik chog'im.
Lekin o'n yetti yosh bolalik emas na xassiz olovsiz yonar o'chog'im
          * * *
Yoshlik dalasida yolg'iz bir o'zim,
Yonimda sayyoh yo'q bitta yo'ldosh yo'q.
Manzilga borishga yetmaydi ko'zim,
Lek otam onam bor shundan ko'nglim to'q.
          * * *
Osmon-u falakka uchganda qushlar,
Bolam deb uchadi shu balki ishi.
Shodon sayraganda o'z ko'nglin hushlar,
Jussasidan katta uning tashvishi.
          * * *
Beparvolik bilan bolalik o'tdi,
Ko'cha ko'yda o'tdi u ham to'grisi.
Biz vaqtni emas vaqt bizni yutdi,
Har kim o'z vaqtining o'zi o'g'risi.
          * * *
Vaqt mashinasin eslayman har gal,
Mung'aygan yurakka taskin bo'lar deb.
Orqaga qaytishga iloj yo'q azal, ovunar ko'ngil o'ziga kelar deb.
          * * *
Jasur bu gaplaring befoyda endi,
Ortga qaytarolmas chiroqda jinlar.
Zoye ketgan axlat unutgin endi,
G'amga chiday olmas tirgak ustunlar.
          * * *
Afsus muammoni bitkazolmaydi,
Har bir onlar uchun ko'zyosh kerakmas. 
Tikan ichidan gul tutqazolmaydi,
Chiday olmas endi yurak tosh emas.
</pre>
              </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="500">
              <i class="bx bxs-user-detail icon-help"></i> <a data-toggle="collapse" href="#faq-list-5" class="collapsed">NEGA KERILAMIZ.<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-5" class="collapse" data-parent=".faq-list">
                <p>
                <pre>

Pul degani oddiy qog'oz faqatgina rangi bor,
Ammo shundayin bo'lsa ham-ki qul kabi egilamiz.
Inson qadri oldida million miliardlar bekor,
Barchamiz bir insonmiz yana nega kerilamiz.
          * * *
Shoh-u gado teng huquqli ollohning dargohida,
Hayotda goh g'alaba bazida yengilamiz.
Ko'ngilni o'ylamasdan kekkayishar  gohida,
Xudo bizni teng qildi nima uchun kerilamiz.
          * * *
Mol-u davlat kul bo'lar yong'indan omon qolmas,
Bevafo hoy havasga chin dildan berilamiz.
Ortiqcha boylik axir insonga tinchlik bermas, 
Shunda ham ishonmayin ne uchun kerilamiz.
           * * *
Hattoki qonunlarda inson qadri yuqori,
Bila turib unga ham indamay ko'z yumamiz.
Boricha sotib olar bo'lsa dunyo bozori,
Tartibni chetlab o'tib qandayin kerilamiz.
          * * *
Tafakkur manmanliklar odamzotga begona,
Kibrni yo'qotishda o'zi istab xohlasin.
Jonzotlardan farqing bor tafakkurda yagona,
Jamiyatda o'rnini anglab yetsin oqlasin.
          * * *
Boylikni pesh qiladi til ketar quloch-quloch,
Insonga hos xulq emas hayvonga teng bo'lamiz.
Maxtumquli aytardi takrorla: "nafsingdan qoch",
Shu gapga parvo qilmay nimaga kerilamiz.
          * * *
Dilimda aytar so'zim yaqinlarni ardoqla,
Jasur sizga o'gatmadi biroz eslatdi xolos.
Oring g'ururingni inson shanini saqla,
Faqat quruq gap emas kichik nasihat bir oz.</pre>
              </p>
              </div>
            </li>
 <li data-aos="fade-up" data-aos-delay="600">
              <i class="bx bxs-user-detail icon-help"></i> <a data-toggle="collapse" href="#faq-list-6" class="collapsed">

SOCHDAGI OQ YUZDAGI AJIN...

<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-6" class="collapse" data-parent=".faq-list">
                <p>
                <pre>


Goho tabassum goho xoxolab kuldim.
Bevafo qiz uchun tirilib òldim,
Bosh borib tekkanda bildim.
Onamning yuziga ajin tushganin,
Otamning sochidan qora uchganin.

Oxiri kòrinmas hayollar bilan.
Kuni òtar bòldi savollar bilan,
Hayot gòzal ekan ģavģolar bilan.
Nechun anglamadim ajin tushganin,
Otamning sochidan qora uchganin.

Sevgi tafti bilan yulduz sanadik.
Bizdan boshqa sevishganlar yòq dedik,
Ayriliqqa chiday olmay òkindik.
Otamning sochdagi oqini kòrib,
Yiģladim yuzdagi ajinni kòrib.

Kerak bòlsa jonimni yulib beraman.
Hatto karvansaroy qurib beraman,
Payģambar yosh tòyin qilib beraman.
Ona oq sutingiz oqlashim uchun,
Ota noningizni oqlashim uchun.

Shirin uyquda paytim otam ekin ekardi.
Menmas òlim kiysin deb kiyim tikib berardi,
Qalbimda otgan vulqon vujudimni ezadi.
Otamning sichdagi oqini kòrib,
Yiģladim yuzdagi ajinni kòrib.

Ularning hayotda òrni yagona.
Hech kim bosolmaydi bitta bir dona,
Hattoki payģambar dedi-ku ona.
Ham taxti ravonim sultonim otam,
Ezgulik timsoli jannatim onam.

Barcha yutuqlarim ota onamga.
Yaxshi niyyatlarim ota onamga,
Dedilar uch marta ota onanga.
Dilginamga yupanch sirdoshim otam,
Kuchim yetmaganda bardoshim onam.

Jasurbek sizlarsiz bòladi ado.
Yoģizlik toshni ham qiladi gado,
Yurakda bittasiz sizlarsiz tanho.
Jonimga quvvatim madorim otam,
Shoir farzand tuqqan qahramon onam.

</pre>
</p>
              </div>
            </li>
<li data-aos="fade-up" data-aos-delay="700">
              <i class="bx bxs-user-detail icon-help"></i> <a data-toggle="collapse" href="#faq-list-7" class="collapsed">

UNUTMA XALQIM.

<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-7" class="collapse" data-parent=".faq-list">
                <p>
                <pre>

Diyorimiz ko‘rdi qancha pahlavonlar,
Yetti iqlim nomin bilgan mard sultonlar.
Amir Temur Boburlar-u Olimxonlar,
Vatanparvar xoqoning unutma xalqim.

Non ustida talashishin kutdi chunon,
Inson emas ular ko‘zi ko‘rdi hayvon.
Birdamlikni ko‘rdi loldir qotdi hayron,
Bir yuz bir o‘g‘loning unutma xalqim.

Mo‘g‘uldan to Gurjistonga safar qilgan,
Chingizxon ham uni ko‘rib niyyat qilgan.
O‘zbek uchun Jaloladdin in‘om qilgan,
Xorazm Manguberding unutma xalqim.

Farzand tog‘i onani yomon qiynaydi,
Qalbi motam tili nolon so‘laydi.
Suv bo‘yida eolib hun-hun yig‘laydi,
Zulfiya ayani unutma xalqim.

U paytda hech kimga oson bo‘lmagan,
Ko‘zi kulib tursa-da qalbi kulmagan.
Hech bir millat farzandin chetda qilmagan,
Shomahmudovlarni unutma xalqim.

Tandirda yopilgan issiq nonini,
Olib ketdi achchiq dard-u zorini.
Dardlarin qo‘zg‘agan ko‘ngil torini,
Bobur Mirzoyingni unutma xalqim.

Shirin jonin to‘shagan har soyanga,
Himolay teng emas tog‘-u qoyanga.
Rimni alishmagan bedapoyanga,
Muhammad Yusufni unutma xalqim.

So‘zda aks etar ming bitta tillo,
Har qator har bayting narxi ming tillo.
Vatanga muhhabat baxsh etganday jo,
Abdullo Orifni unutma xalqim.

She‘riyat bo‘stonida o‘rni beqiyos,
Har necha ta‘rif va tasniflarim oz.
Ibroyim Yusupov ijodidan yoz,
Qoraqalpoq farzandin unutma xalqim.

Ko‘zi kulib turgan shirin so‘z edi,
Insonga xush yoqar shirin so‘z edi.
Do‘stim deb aytganga yaxshi do‘st edi,
Islom bobomizni unutma xalqim.

Har tomoni gulzor yo‘llari ravon,
Qurigan oroldan yaratdi bo‘ston.
Mo‘min kishi edi farishta inson,
Unutmagin Muso Yerniyozovni.

Vatanparvar edi ilmga chanqoq,
Aslo bezmas edi kitobga o‘rtoq.
Andishaning otin qo‘yganda qo‘rqoq,
Bexbudiy Cho‘lponing unutma xalqim.

Fidokor xalqing bor mehnatkash suyuk,
Ularning nomlari tarixda buyuk.
Bu bitta topshiriq va muqaddas yuk, 
Xalqim deb yonganni unutma xalqim.

Sahardan shomgacha dalada qolsa,
Bola-chaqamga deb yelib yugursa.
Tarixda nomlari bir-bir o‘qilsa,
Shu qorako‘zlarni unutma xalqim.

</pre>
</p>
              </div>
            </li>

<li data-aos="fade-up" data-aos-delay="800">
              <i class="bx bxs-user-detail icon-help"></i> <a data-toggle="collapse" href="#faq-list-8" class="collapsed">

ISHQ TA'RIFI.

<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-8" class="collapse" data-parent=".faq-list">
                <p>
                <pre>

Yor vaslin qoğozga nozil etmasa,
Unga atab she'ru ash'or bitmasa.
Qòldan tutib ishq boğoga eltmasa,
Shoir deb aytishga gumonli bòlar.

Axir ishq shoirga qalam tutqazgan,
Garchan urinsa ham mağlub yutqazgan.
Oxir muhabbatga tòrtlik bitkazgan,
Chin sevgi insonni har kòyga solur.

Tunlar uyqu qochsa, qaro kòzlardan,
Charchasa "u qizdan umid uz"lardan.
Ming doston bòladi har bir sòzlardan,
Goh shodon goh mayis qilgan bu ishq.

Chin sevgi oshiqni sarmasd etadi,
Gohi baland bòlib goh past ketadi.
Jafoga chidolmay qasd etadi,
Aql hushni olgan shu ishq bòladi.

Taqdir qòshilsa deb qiladi niyyat,
Tòsatdan keladi zòr imkoniyat.
Balkim orasiga tushmay ziddiyat,
Niyyati ròyobga chiqishi mumkin.

Jasur ishq ta'rifin uzoq sòylading,
Oshiqlar kuyini biroz kuylading.
Endi ortga tomon qaytar vaqt keldi,
Dard-u tashvishlarin sen ham òylading.

</pre>
</p>
              </div>
            </li>


<!-- <li data-aos="fade-up" data-aos-delay="900">
              <i class="bx bxs-user-detail icon-help"></i> <a data-toggle="collapse" href="#faq-list-9" class="collapsed">



<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-9" class="collapse" data-parent=".faq-list">
                <p>
                <pre>


</pre>
</p>
              </div>
            </li> -->


          </ul>
        </div>

      </div>
    </section> <!-- End Frequently Asked Questions Section -->

        </div>
<!-- End Portfolio Details Section -->

<?php include "includes/footer.php"; ?>