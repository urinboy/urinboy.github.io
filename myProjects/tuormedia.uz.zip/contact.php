<?php
$page_id = '';
$page_url = "/contact.php";
$title = "Biz bilan bog'lanish";
$site_name = "TUORMedia.uz";
include "includes/header.php";

?>

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Biz bilan bog'lanish</h2>
        </div>

        <div class="row mt-1 d-flex justify-content-end" data-aos="fade-right" data-aos-delay="100">

          <div class="col-lg-5">
            <div class="info">
              <div class="address">
                <i class="icofont-google-map"></i>
                <h4>Manzil:</h4>
                <p>O'zbekiston, Qoraqalpog'iston Respublikasi, Taxiatosh tumani, Keneges OFY</p>
              </div>

              <div class="email">
                <i class="icofont-envelope"></i>
                <h4>Email:</h4>
                <p>urinboytursunboev@gmail.com</p>
              </div>

              <div class="phone">
                <i class="icofont-phone"></i>
                <h4>Tel:</h4>
                <p>+998 91 373 11 96</p>
              </div>

            </div>

          </div>

          <div class="col-lg-6 mt-5 mt-lg-0" data-aos="fade-left" data-aos-delay="100">

          <form action="/proses.php" method="post" role="form" class="php-email-form">
          
          <?php 
            $msg = "";
            if (isset($_GET['error'])) {
                $msg = "Iltimos tekshirib xatolarni to'g'irilang!";
                echo '<div class="alert alert-danger">'.$msg.'</div>';
            }
                if (isset($_GET['success'])) {
                    $msg = "Xabaringiz jo`natildi!";
                    echo '<div class="alert alert-success">'.$msg.'</div>';
                }
          ?>
 
             <div class="form-row">
                  
                <div class="col-md-6 form-group">
                  <input type="text" name="contact_username" class="form-control" placeholder="Ism"/>
                </div>
                <div class="col-md-6 form-group">
                  <input type="email" class="form-control" name="contact_email" placeholder="address@tuormedia.uz" />
                </div>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="subject" placeholder="Mavzu" />
                </div>
                <div class="form-group">
                    <textarea class="form-control mb-2" name="message" rows="8"   placeholder="Xabar"></textarea>
                </div>
        <!-- <div class="mb-3">
                <div class="loading">Yuborilmoqda</div>
                <div class="error-message"></div>
                <div class="sent-message">Raxmat sizning xabaringiz yuborildi!</div> 
              </div> -->

              <div class="text-center"><button type="submit" name="submit">Xabarni yuborish</button></div>
            </form>

          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->


<?php include "includes/footer.php"; ?>