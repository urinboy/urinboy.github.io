<?php
   session_start();

    $page_id = '';
    $page_url = "/login.php";
    $title = "Tizimga kirish";
    $site_name = "TUORMedia.uz";
    include "includes/header.php";
?>
<?php

    include 'config.php';

    if(isset($_POST['submit'])){
        
        $email = $_POST['email'];
        $password = $_POST['password'];

        $email_search = "SELECT * FROM users WHERE email='$email'";
        $query = mysqli_query($conn, $email_search);

        $email_count = mysqli_num_rows($query);

        if ($email_count) 
        {
            $email_pass = mysqli_fetch_assoc($query);
            $db_pass = $email_pass['password'];
            $pass_decode = password_verify($password, $db_pass);

            if ($pass_decode) 
            {
                //echo "Siz tizimga kirdingiz!";
                ?>
                <script>
                    location.replace("home.php");
                </script>
                <?php
            }
             else 
            {
                ?>
                <script>
                    alert("Parol noto`g`ri!");
                </script>
                <?php
            }

        } 
        else 
        {
            ?>
            <script>
                alert("Elektron pochta yaroqsiz!");
            </script>
            <?php
        }
       
    }
    
?>
    <div class="card bg-light form-div">
        <article class="card-body mx-auto" style="max-width: 400px;">
            <h3 class="card-title mt-3 text-center"><?php echo $title; ?></h3>
            <p class="text-center alert alert-success">Boshlash uchun saytga kiring!</p>
            <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="POST">
                <div class="form-group input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fa fa-user"></i></span>
                    </div>
                    <input type="text" name="email" class="form-control" placeholder="Email" required>
                </div>
                <div class="form-group input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fa fa-lock"></i></span>
                    </div>
                    <input type="password" name="password" class="form-control" placeholder="Parol" required>
                </div>
                <div class="form-group">
                    <button type="submit" name="submit" class="btn btn-primary btn-block">Kirish</button>
                </div>
                <p class="text-center">A'zo bo'lmaganmisiz? <a href="/register.php">A'zo bo'lish</a></p>
            </form>
            
            <p class="divider-text">
                <span class="bg-light">YOKI</span>
            </p>

            <p>
                <a href="" class="btn btn-block btn-gmail"><i class="fa fa-google"></i>  Google orqali kirish</a>
                <a href="" class="btn btn-block btn-facebook"><i class="fa fa-facebook"></i>  Facebook orqali kirish</a>
            </p>

        </article>
    </div>


<?php
    include "includes/footer.php";
?>