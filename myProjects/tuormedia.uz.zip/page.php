<?php
$page_id = 2;
$page_url = "/page.php";
$title = "Sahifa";
$site_name = "TUORMethods.uz";
include "includes/header.php";
?>
    <!-- ======= Why Us Section ======= -->
    <section id="why-us" class="why-us">
      <div class="container-fluid">

        <div class="row">

          <div class="col-lg-5 align-items-stretch video-box" style='background-image: url("assets/img/5tashabbus.jpg");' data-aos="fade-right">
            <a href="https://www.youtube.com/watch?v=cHeiv3Giyfk" class="venobox play-btn mb-4" data-vbtype="video" data-autoplay="true"></a>
          </div>

          <div class="col-lg-7 d-flex flex-column justify-content-center align-items-stretch" data-aos="fade-left">

            <div class="content">
              <h3>Yoshlar ma'naviyatini yuksaltirish va ularning bosh vaqtini mazmunli tashlik etish bo'yicha <strong>5 ta muhim tashabbus!</strong></h3>
              <p>

              </p>
            </div>

            <div class="accordion-list">
              <ul>
                <li data-aos="fade-up" data-aos-delay="100">
                  <a data-toggle="collapse" class="collapsed" href="#accordion-list-1"><span>01</span>- tashabbus. San'at va madaniyat <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="accordion-list-1" class="collapse" data-parent=".accordion-list">
                    <p>
                        Yoshlarning <b>musiqa, rassomlik, adabiyot, teatr va san'atning </b>boshqa turlariga qiziqishlarini oshirishga, istedoni yuzaga chiqarishga xizmat qiladi.
                    </p>
                  </div>
                </li>

                <li data-aos="fade-up" data-aos-delay="200">
                  <a data-toggle="collapse" href="#accordion-list-2" class="collapsed"><span>02</span>- tashabbus. Sport <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="accordion-list-2" class="collapse" data-parent=".accordion-list">
                    <p>
                        Yoshlarni jismoniy chiniqtirish, ularning <b>sport</b> sohasida qobiliyatini namoyish qilishlari uchunzarur sharoitlarni yaratishga yo'naltirilgan.                  </p>
                  </div>
                </li>

                <li data-aos="fade-up" data-aos-delay="300">
                  <a data-toggle="collapse" href="#accordion-list-3" class="collapsed"><span>03</span>- tashabbus. Axborot texnologiyalari <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="accordion-list-3" class="collapse" data-parent=".accordion-list">
                    <p>
                        Aholi va yoshlar o'rtasida  <b>Kompyuter texnologiyalari va internet</b>dan samarali foydalanishni tashkil etishga qaratish.                    </p>
                  </div>
                </li>
                <li data-aos="fade-up" data-aos-delay="400">
                  <a data-toggle="collapse" href="#accordion-list-4" class="collapsed"><span>04</span>- tashabbus. Mutoala <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="accordion-list-4" class="collapse" data-parent=".accordion-list">
                    <p>
                        Yoshlar ma'naviyatini yuksaltirish, ular o'rtasida <b> kitobxonlikni</b> keng targ'ib qilish bo'yicha tizimli ishlarni tashkil etishga yo'naltirilgan.
                    </p>
                  </div>
                </li>
                <li data-aos="fade-up" data-aos-delay="500">
                  <a data-toggle="collapse" href="#accordion-list-5" class="collapsed"><span>05</span>- tashabbus. Xotin qizlar <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="accordion-list-5" class="collapse" data-parent=".accordion-list">
                    <p>
                        Xotin-qizlarni <b>ish bilan ta'minlash</b> masalalarini nazarda tutadi.
                    </p>
                  </div>
                </li>

              </ul>
            </div>

          </div>

        </div>

      </div>
    </section><!-- End Why Us Section -->





<?php
include "includes/footer.php";
?>