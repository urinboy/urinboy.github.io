<?php
   session_start();

    $page_id = '';
    $page_url = "/register.php";
    $title = "Tizimdan ro`yxatdan o`tish";
    $site_name = "TUORMedia.uz";
    include "includes/header.php";
?>
<?php

    include 'config.php';

    if (isset($_POST['submit'])) {
        $username = mysqli_real_escape_string($conn, $_POST['username']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $phone = mysqli_real_escape_string($conn, $_POST['phone']);
        $password = mysqli_real_escape_string($conn, $_POST['password']);
        $cpassword = mysqli_real_escape_string($conn, $_POST['cpassword']);

        // parolni hash qilish
        $pass = password_hash($password, PASSWORD_BCRYPT);
        $cpass = password_hash($cpassword, PASSWORD_BCRYPT);

        // emailni bazadan tekshirish
        $emailQuery = "SELECT * FROM users WHERE email='$email'";
        $query = mysqli_query($conn, $emailQuery);

        $emailCount =mysqli_num_rows($query);

        if ($emailCount > 0) {
            ?>
            <script>
                alert("Bu elektron pochta avval ro'yxatdan o'tgan!");
            </script>
            <?php
        }else {
            if ($password === $cpassword) {
                // Bazaga ma`lumotlarni joylash
                $insertQuery = "INSERT INTO users(username,email,phone,password,cpassword) VALUES('$username','$email','$phone','$pass','$cpass')";
            
                $iquery = mysqli_query($conn, $insertQuery);

                
                if ($iquery) {
                    ?>
                    <script>
                        alert("Tizimdam mavaffaqiyatli ro`yxatdan o`tdingiz!");
                    </script>
                    <?php
                } else{
                    ?>
                    <script>
                        alert("Xatolik ma'lumot yuborilmadi!");
                    </script>
                    <?php
                }



            }else {
                ?>
                <script>
                    alert("Parol bir xil emas!");
                </script>
                <?php
            }
        }

    }
?>
    <div class="card bg-light form-div">
        <article class="card-body mx-auto" style="max-width: 400px;">
            <h3 class="card-title mt-3 text-center"><?php echo $title; ?></h3>
            <p class="text-center alert alert-success">Boshlash uchun saytga a'zo bo'ling!</p>
            <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="POST">
                <div class="form-group input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fa fa-user"></i></span>
                    </div>
                    <input type="text" name="username" class="form-control" placeholder="To`liq ism" required>
                </div>
                <div class="form-group input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fa fa-envelope"></i></span>
                    </div>
                    <input type="email" name="email" class="form-control" placeholder="Elektron manzil" required>
                </div>
                <div class="form-group input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fa fa-phone"></i></span>
                    </div>
                    <input type="number" name="phone" class="form-control" placeholder="Telefon raqam" required>
                </div>
                <div class="form-group input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fa fa-lock"></i></span>
                    </div>
                    <input type="password" name="password" class="form-control" placeholder="Parol" required>
                </div>
                <div class="form-group input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fa fa-lock"></i></span>
                    </div>
                    <input type="password" name="cpassword" class="form-control" placeholder="Parolni tasdiqlash" required>
                </div>
                <div class="form-group">
                    <button type="submit" name="submit" class="btn btn-primary btn-block">A'zo bo'lish</button>
                </div>
                <p class="text-center">A'zo bo'ldingizmi'? <a href="/login.php">Kirish</a></p>
            </form>
            
            <p class="divider-text">
                <span class="bg-light">YOKI</span>
            </p>

            <p>
                <a href="" class="btn btn-block btn-gmail"><i class="fa fa-google"></i>  Google orqali kirish</a>
                <a href="" class="btn btn-block btn-facebook"><i class="fa fa-facebook"></i>  Facebook orqali kirish</a>
            </p>

        </article>
    </div>


<?php
    include "includes/footer.php";
?>