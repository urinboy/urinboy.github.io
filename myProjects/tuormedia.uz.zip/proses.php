<?php

if (isset($_POST['submit'])) {
    $username = $_POST['contact_username'];
    $email = $_POST['contact_email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];
    
    // tekshirish uchun
    
    if(empty($username) || empty($email) || empty($subject) || empty($message))
    {   
        header ("location:contact.php?error");
    }
    else 
    {
      $to = "urinboytursunboev@gmail.com";

      if(mail($to,$subject,$message,$email)) 
      {
        header("location:contact.php?success");
      }
    }
} 
else 
{
    header("location:contact.php");
}


?>