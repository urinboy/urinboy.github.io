<?php
$page_id = 2;
$page_url = "/page.php";
$title = "Sahifa";
$site_name = "TUORMethods.uz";
include "includes/header.php";
?>
    <!-- ======= Blog Section ======= -->
    <section id="news" class="blog">
       <div class="container">
           <div class="row">



           </div>
            <div class="blog-pagination" data-aos="fade-up">
                <ul class="justify-content-center">
                    <li class="disabled"><i class="icofont-rounded-left"></i></li>
                    <li><a href="#">1</a></li>
                    <li class="active"><a href="#">2</a></li>
                    <li><a href="#">3</a></li>
                    <li><a href="#"><i class="icofont-rounded-right"></i></a></li>
                </ul>
            </div>
      </div>
    </section><!-- End Blog Section -->
<?php
include "includes/footer.php";
?>