<?php
    $SERVER ="localhost";
    $USER = "tuormedia_tuormedia";
    $PASS = "Salom@1196";
    $DB = "tuormedia_tuormedia";

    $conn = mysqli_connect($SERVER,$USER,$PASS,$DB);

    if ($conn) 
    {
        ?>
        <!--<script>
            alert("Baza mavaffaqiyatli ulandi");
        </script>-->
        <?php
    } 
    else
    {
        ?>
        <script>
            alert("Baza tizmga ulanmagan");
        </script>
        <?php
    }
?>