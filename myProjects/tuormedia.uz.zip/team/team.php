    <!-- ======= Team Section ======= -->
    <section id="team" class="team section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Jamoa a'zolari</h2>
          <p></p>
        </div>

        <div class="row">

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
            <div class="member d-flex align-items-start">
            <div class="pic"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHgAAAB4CAYAAAA5ZDbSAAAEZ0lEQVR4nO2dIXAUMRSGEScQFchKRGUFAlFR8ZKpQFRUIBEVCAQCgajcGab70lacQCAqKyoQCEQF4gQCiUAgKiqOfbm5ioqKihOHaOi00+nBltt9Sfb/Zn57c/v/k93Ne9nkwQMAAAAAAAAAAAAAAIASVEx7xJ7IVXu29IeGZWDYHxuW86ATwzKwpT8kJ33iao2KaU/7f4MZUDHtUSkbluXAsJwalmktOTmzLAdUygbCjgzias04+V471LvD/k5crWlfV+eh7dGyYTmaW7C3dUTbo2Xt6+wk5OSFYbloMNw/uiAnL7Svt1NQKe9aCPaGyFV7eDY3DBXTnnXyse1wb9yyi/GCtg/ZYln2FcOdGpapLf2htg9ZYkt5ox3uVchcFdp+ZAWxPDMsE+1gr4tK/1zblyyg4uShYfHagd6SkzMqTh5p+5M8lqtCPcw7R7Gwtj9JQ7vjRXNZO1YP8w5d0O54UdunZCGWDxGEOFOWZV/bpyQJz96YR+8fnVNx8lDbr+QIb87a4f2TiOWZtl/JEUNRA7fpBjEsQ+3gamio7VdSEPvHEYRW8zbtH2v7lgy0M1rRDqx2wDujFW3fkoHK0bp2YLUDLkfr2r4lA7G81A6sdsAsL7V9S4aYy5N3CR2mGmAEZw6VsqEdWO2AS9nQ9i0Z8BadOZgHZw4V0565z9cJejrV9iw5UIvOnJSKHShy3AP0gzsAVnRkDtZkdYCYy5ZYVTkHsC66A+DLhg5gS/9WO9Rrt+Z32n5kSdh/QzVcy9VnbR+yJTyPvygG/BXfBzfM5RZJ7c+PLcs+vvBvEcvyyrTz4jWxXL3Wvt5OQk5WDcugwXAH6PNGQFgB8mOOwf7ACo3IwE53HQJ7VQIAAAAAAAAAAAAAABqCeLhE7Detky1y0g815+slyHl3ks7Db1+VNK2TLWK/iXMc5gTtjFYut+/3xy30fWvKH5Or9sjJqrZPSUFOVsOKjZT2yfKWZR9H8cyAduSpabZ535a+YlRfg3i4FFp62sHMVdbJR+Lhkra/atDueJHYvzeRLWifsybE/n3nvl8Ka6ni+xylOZ0Se9L2vRWI/Wbmo3bGaM58qyWNE8tiEznpZ7c8iIrxgnXySdvciJTPCWpUjBcMV98iMDU2/cwiZIzcmTpK+naNZ+7fRU762jndi/C2rG5gCkru7TrMc7s4FbqvJsnMk8POOF0qYsxLp0lUvEL5UdusJBX985h4uGRwa/4fTaJuUOTYFWpb0Z4wHvq56gblINr+9UQ7z1uYPJr1sWignecNwrRI25SsFNWqkBR2hU1NxPJBO9crTFoL5FJRHAdepnhCSiqKYocfNBQaDDiGPTHjXJSei/yxarihchWBEflKtbKFlmAbAftNtYCtky1tA3KXdbKlFjA56WsbkLtUO0wxbNCduyzLgVrABvXnNqRXl8YUqQ0pTpVM3IdW5aJzzYC1L74TQsCZCwFnLgScuRBw5lILGAAAAAAAAAAAAAAAAAAAAACQMr8BLfRpvN2x3EMAAAAASUVORK5CYII=" class="img-fluid" alt=""/></div>
              <div class="member-info">
                <h4>O'rinboy Tursunboyev</h4>
                <span>Sayt yaratuvchi</span>
                <p>Life good</p>
                <div class="social">
                  <a href=""><i class="ri-twitter-fill"></i></a>
                  <a href=""><i class="ri-facebook-fill"></i></a>
                  <a href=""><i class="ri-instagram-fill"></i></a>
                  <a href=""> <i class="ri-linkedin-box-fill"></i> </a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-6 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="200">
            <div class="member d-flex align-items-start">
            <div class="pic"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHgAAAB4CAYAAAA5ZDbSAAAEZ0lEQVR4nO2dIXAUMRSGEScQFchKRGUFAlFR8ZKpQFRUIBEVCAQCgajcGab70lacQCAqKyoQCEQF4gQCiUAgKiqOfbm5ioqKihOHaOi00+nBltt9Sfb/Zn57c/v/k93Ne9nkwQMAAAAAAAAAAAAAAIASVEx7xJ7IVXu29IeGZWDYHxuW86ATwzKwpT8kJ33iao2KaU/7f4MZUDHtUSkbluXAsJwalmktOTmzLAdUygbCjgzias04+V471LvD/k5crWlfV+eh7dGyYTmaW7C3dUTbo2Xt6+wk5OSFYbloMNw/uiAnL7Svt1NQKe9aCPaGyFV7eDY3DBXTnnXyse1wb9yyi/GCtg/ZYln2FcOdGpapLf2htg9ZYkt5ox3uVchcFdp+ZAWxPDMsE+1gr4tK/1zblyyg4uShYfHagd6SkzMqTh5p+5M8lqtCPcw7R7Gwtj9JQ7vjRXNZO1YP8w5d0O54UdunZCGWDxGEOFOWZV/bpyQJz96YR+8fnVNx8lDbr+QIb87a4f2TiOWZtl/JEUNRA7fpBjEsQ+3gamio7VdSEPvHEYRW8zbtH2v7lgy0M1rRDqx2wDujFW3fkoHK0bp2YLUDLkfr2r4lA7G81A6sdsAsL7V9S4aYy5N3CR2mGmAEZw6VsqEdWO2AS9nQ9i0Z8BadOZgHZw4V0565z9cJejrV9iw5UIvOnJSKHShy3AP0gzsAVnRkDtZkdYCYy5ZYVTkHsC66A+DLhg5gS/9WO9Rrt+Z32n5kSdh/QzVcy9VnbR+yJTyPvygG/BXfBzfM5RZJ7c+PLcs+vvBvEcvyyrTz4jWxXL3Wvt5OQk5WDcugwXAH6PNGQFgB8mOOwf7ACo3IwE53HQJ7VQIAAAAAAAAAAAAAABqCeLhE7Detky1y0g815+slyHl3ks7Db1+VNK2TLWK/iXMc5gTtjFYut+/3xy30fWvKH5Or9sjJqrZPSUFOVsOKjZT2yfKWZR9H8cyAduSpabZ535a+YlRfg3i4FFp62sHMVdbJR+Lhkra/atDueJHYvzeRLWifsybE/n3nvl8Ka6ni+xylOZ0Se9L2vRWI/Wbmo3bGaM58qyWNE8tiEznpZ7c8iIrxgnXySdvciJTPCWpUjBcMV98iMDU2/cwiZIzcmTpK+naNZ+7fRU762jndi/C2rG5gCkru7TrMc7s4FbqvJsnMk8POOF0qYsxLp0lUvEL5UdusJBX985h4uGRwa/4fTaJuUOTYFWpb0Z4wHvq56gblINr+9UQ7z1uYPJr1sWignecNwrRI25SsFNWqkBR2hU1NxPJBO9crTFoL5FJRHAdepnhCSiqKYocfNBQaDDiGPTHjXJSei/yxarihchWBEflKtbKFlmAbAftNtYCtky1tA3KXdbKlFjA56WsbkLtUO0wxbNCduyzLgVrABvXnNqRXl8YUqQ0pTpVM3IdW5aJzzYC1L74TQsCZCwFnLgScuRBw5lILGAAAAAAAAAAAAAAAAAAAAACQMr8BLfRpvN2x3EMAAAAASUVORK5CYII=" class="img-fluid" alt=""/></div>
              <div class="member-info">
                <h4>Muxlisa Olimboyeva</h4>
                <span>Proyekt menejeri</span>
                <p>Life good</p>
                <div class="social">
                  <a href=""><i class="ri-twitter-fill"></i></a>
                  <a href=""><i class="ri-facebook-fill"></i></a>
                  <a href=""><i class="ri-instagram-fill"></i></a>
                  <a href=""> <i class="ri-linkedin-box-fill"></i> </a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-6 mt-4" data-aos="fade-up" data-aos-delay="300">
            <div class="member d-flex align-items-start">
            <div class="pic"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHgAAAB4CAYAAAA5ZDbSAAAEZ0lEQVR4nO2dIXAUMRSGEScQFchKRGUFAlFR8ZKpQFRUIBEVCAQCgajcGab70lacQCAqKyoQCEQF4gQCiUAgKiqOfbm5ioqKihOHaOi00+nBltt9Sfb/Zn57c/v/k93Ne9nkwQMAAAAAAAAAAAAAAIASVEx7xJ7IVXu29IeGZWDYHxuW86ATwzKwpT8kJ33iao2KaU/7f4MZUDHtUSkbluXAsJwalmktOTmzLAdUygbCjgzias04+V471LvD/k5crWlfV+eh7dGyYTmaW7C3dUTbo2Xt6+wk5OSFYbloMNw/uiAnL7Svt1NQKe9aCPaGyFV7eDY3DBXTnnXyse1wb9yyi/GCtg/ZYln2FcOdGpapLf2htg9ZYkt5ox3uVchcFdp+ZAWxPDMsE+1gr4tK/1zblyyg4uShYfHagd6SkzMqTh5p+5M8lqtCPcw7R7Gwtj9JQ7vjRXNZO1YP8w5d0O54UdunZCGWDxGEOFOWZV/bpyQJz96YR+8fnVNx8lDbr+QIb87a4f2TiOWZtl/JEUNRA7fpBjEsQ+3gamio7VdSEPvHEYRW8zbtH2v7lgy0M1rRDqx2wDujFW3fkoHK0bp2YLUDLkfr2r4lA7G81A6sdsAsL7V9S4aYy5N3CR2mGmAEZw6VsqEdWO2AS9nQ9i0Z8BadOZgHZw4V0565z9cJejrV9iw5UIvOnJSKHShy3AP0gzsAVnRkDtZkdYCYy5ZYVTkHsC66A+DLhg5gS/9WO9Rrt+Z32n5kSdh/QzVcy9VnbR+yJTyPvygG/BXfBzfM5RZJ7c+PLcs+vvBvEcvyyrTz4jWxXL3Wvt5OQk5WDcugwXAH6PNGQFgB8mOOwf7ACo3IwE53HQJ7VQIAAAAAAAAAAAAAABqCeLhE7Detky1y0g815+slyHl3ks7Db1+VNK2TLWK/iXMc5gTtjFYut+/3xy30fWvKH5Or9sjJqrZPSUFOVsOKjZT2yfKWZR9H8cyAduSpabZ535a+YlRfg3i4FFp62sHMVdbJR+Lhkra/atDueJHYvzeRLWifsybE/n3nvl8Ka6ni+xylOZ0Se9L2vRWI/Wbmo3bGaM58qyWNE8tiEznpZ7c8iIrxgnXySdvciJTPCWpUjBcMV98iMDU2/cwiZIzcmTpK+naNZ+7fRU762jndi/C2rG5gCkru7TrMc7s4FbqvJsnMk8POOF0qYsxLp0lUvEL5UdusJBX985h4uGRwa/4fTaJuUOTYFWpb0Z4wHvq56gblINr+9UQ7z1uYPJr1sWignecNwrRI25SsFNWqkBR2hU1NxPJBO9crTFoL5FJRHAdepnhCSiqKYocfNBQaDDiGPTHjXJSei/yxarihchWBEflKtbKFlmAbAftNtYCtky1tA3KXdbKlFjA56WsbkLtUO0wxbNCduyzLgVrABvXnNqRXl8YUqQ0pTpVM3IdW5aJzzYC1L74TQsCZCwFnLgScuRBw5lILGAAAAAAAAAAAAAAAAAAAAACQMr8BLfRpvN2x3EMAAAAASUVORK5CYII=" class="img-fluid" alt=""/></div>
              <div class="member-info">
                <h4>Asror Karimov</h4>
                <span>Freelanser</span>
                <p>Life good</p>
                <div class="social">
                  <a href=""><i class="ri-twitter-fill"></i></a>
                  <a href=""><i class="ri-facebook-fill"></i></a>
                  <a href=""><i class="ri-instagram-fill"></i></a>
                  <a href=""> <i class="ri-linkedin-box-fill"></i> </a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-6 mt-4" data-aos="fade-up" data-aos-delay="400">
            <div class="member d-flex align-items-start">
            <div class="pic"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHgAAAB4CAYAAAA5ZDbSAAAEZ0lEQVR4nO2dIXAUMRSGEScQFchKRGUFAlFR8ZKpQFRUIBEVCAQCgajcGab70lacQCAqKyoQCEQF4gQCiUAgKiqOfbm5ioqKihOHaOi00+nBltt9Sfb/Zn57c/v/k93Ne9nkwQMAAAAAAAAAAAAAAIASVEx7xJ7IVXu29IeGZWDYHxuW86ATwzKwpT8kJ33iao2KaU/7f4MZUDHtUSkbluXAsJwalmktOTmzLAdUygbCjgzias04+V471LvD/k5crWlfV+eh7dGyYTmaW7C3dUTbo2Xt6+wk5OSFYbloMNw/uiAnL7Svt1NQKe9aCPaGyFV7eDY3DBXTnnXyse1wb9yyi/GCtg/ZYln2FcOdGpapLf2htg9ZYkt5ox3uVchcFdp+ZAWxPDMsE+1gr4tK/1zblyyg4uShYfHagd6SkzMqTh5p+5M8lqtCPcw7R7Gwtj9JQ7vjRXNZO1YP8w5d0O54UdunZCGWDxGEOFOWZV/bpyQJz96YR+8fnVNx8lDbr+QIb87a4f2TiOWZtl/JEUNRA7fpBjEsQ+3gamio7VdSEPvHEYRW8zbtH2v7lgy0M1rRDqx2wDujFW3fkoHK0bp2YLUDLkfr2r4lA7G81A6sdsAsL7V9S4aYy5N3CR2mGmAEZw6VsqEdWO2AS9nQ9i0Z8BadOZgHZw4V0565z9cJejrV9iw5UIvOnJSKHShy3AP0gzsAVnRkDtZkdYCYy5ZYVTkHsC66A+DLhg5gS/9WO9Rrt+Z32n5kSdh/QzVcy9VnbR+yJTyPvygG/BXfBzfM5RZJ7c+PLcs+vvBvEcvyyrTz4jWxXL3Wvt5OQk5WDcugwXAH6PNGQFgB8mOOwf7ACo3IwE53HQJ7VQIAAAAAAAAAAAAAABqCeLhE7Detky1y0g815+slyHl3ks7Db1+VNK2TLWK/iXMc5gTtjFYut+/3xy30fWvKH5Or9sjJqrZPSUFOVsOKjZT2yfKWZR9H8cyAduSpabZ535a+YlRfg3i4FFp62sHMVdbJR+Lhkra/atDueJHYvzeRLWifsybE/n3nvl8Ka6ni+xylOZ0Se9L2vRWI/Wbmo3bGaM58qyWNE8tiEznpZ7c8iIrxgnXySdvciJTPCWpUjBcMV98iMDU2/cwiZIzcmTpK+naNZ+7fRU762jndi/C2rG5gCkru7TrMc7s4FbqvJsnMk8POOF0qYsxLp0lUvEL5UdusJBX985h4uGRwa/4fTaJuUOTYFWpb0Z4wHvq56gblINr+9UQ7z1uYPJr1sWignecNwrRI25SsFNWqkBR2hU1NxPJBO9crTFoL5FJRHAdepnhCSiqKYocfNBQaDDiGPTHjXJSei/yxarihchWBEflKtbKFlmAbAftNtYCtky1tA3KXdbKlFjA56WsbkLtUO0wxbNCduyzLgVrABvXnNqRXl8YUqQ0pTpVM3IdW5aJzzYC1L74TQsCZCwFnLgScuRBw5lILGAAAAAAAAAAAAAAAAAAAAACQMr8BLfRpvN2x3EMAAAAASUVORK5CYII=" class="img-fluid" alt=""/></div>
              <div class="member-info">
                <h4>Bexzod Qo'ldoshev</h4>
                <span>Veb dasturchi</span>
                <p>Life good</p>
                <div class="social">
                  <a href=""><i class="ri-twitter-fill"></i></a>
                  <a href=""><i class="ri-facebook-fill"></i></a>
                  <a href=""><i class="ri-instagram-fill"></i></a>
                  <a href=""> <i class="ri-linkedin-box-fill"></i> </a>
                </div>
              </div>
            </div>
          </div>
          <br>
          <br>
          <div class="col-lg-6 mt-4" data-aos="fade-up" data-aos-delay="500">
            <div class="member d-flex align-items-start">
            <div class="pic"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHgAAAB4CAYAAAA5ZDbSAAAEZ0lEQVR4nO2dIXAUMRSGEScQFchKRGUFAlFR8ZKpQFRUIBEVCAQCgajcGab70lacQCAqKyoQCEQF4gQCiUAgKiqOfbm5ioqKihOHaOi00+nBltt9Sfb/Zn57c/v/k93Ne9nkwQMAAAAAAAAAAAAAAIASVEx7xJ7IVXu29IeGZWDYHxuW86ATwzKwpT8kJ33iao2KaU/7f4MZUDHtUSkbluXAsJwalmktOTmzLAdUygbCjgzias04+V471LvD/k5crWlfV+eh7dGyYTmaW7C3dUTbo2Xt6+wk5OSFYbloMNw/uiAnL7Svt1NQKe9aCPaGyFV7eDY3DBXTnnXyse1wb9yyi/GCtg/ZYln2FcOdGpapLf2htg9ZYkt5ox3uVchcFdp+ZAWxPDMsE+1gr4tK/1zblyyg4uShYfHagd6SkzMqTh5p+5M8lqtCPcw7R7Gwtj9JQ7vjRXNZO1YP8w5d0O54UdunZCGWDxGEOFOWZV/bpyQJz96YR+8fnVNx8lDbr+QIb87a4f2TiOWZtl/JEUNRA7fpBjEsQ+3gamio7VdSEPvHEYRW8zbtH2v7lgy0M1rRDqx2wDujFW3fkoHK0bp2YLUDLkfr2r4lA7G81A6sdsAsL7V9S4aYy5N3CR2mGmAEZw6VsqEdWO2AS9nQ9i0Z8BadOZgHZw4V0565z9cJejrV9iw5UIvOnJSKHShy3AP0gzsAVnRkDtZkdYCYy5ZYVTkHsC66A+DLhg5gS/9WO9Rrt+Z32n5kSdh/QzVcy9VnbR+yJTyPvygG/BXfBzfM5RZJ7c+PLcs+vvBvEcvyyrTz4jWxXL3Wvt5OQk5WDcugwXAH6PNGQFgB8mOOwf7ACo3IwE53HQJ7VQIAAAAAAAAAAAAAABqCeLhE7Detky1y0g815+slyHl3ks7Db1+VNK2TLWK/iXMc5gTtjFYut+/3xy30fWvKH5Or9sjJqrZPSUFOVsOKjZT2yfKWZR9H8cyAduSpabZ535a+YlRfg3i4FFp62sHMVdbJR+Lhkra/atDueJHYvzeRLWifsybE/n3nvl8Ka6ni+xylOZ0Se9L2vRWI/Wbmo3bGaM58qyWNE8tiEznpZ7c8iIrxgnXySdvciJTPCWpUjBcMV98iMDU2/cwiZIzcmTpK+naNZ+7fRU762jndi/C2rG5gCkru7TrMc7s4FbqvJsnMk8POOF0qYsxLp0lUvEL5UdusJBX985h4uGRwa/4fTaJuUOTYFWpb0Z4wHvq56gblINr+9UQ7z1uYPJr1sWignecNwrRI25SsFNWqkBR2hU1NxPJBO9crTFoL5FJRHAdepnhCSiqKYocfNBQaDDiGPTHjXJSei/yxarihchWBEflKtbKFlmAbAftNtYCtky1tA3KXdbKlFjA56WsbkLtUO0wxbNCduyzLgVrABvXnNqRXl8YUqQ0pTpVM3IdW5aJzzYC1L74TQsCZCwFnLgScuRBw5lILGAAAAAAAAAAAAAAAAAAAAACQMr8BLfRpvN2x3EMAAAAASUVORK5CYII=" class="img-fluid" alt=""/></div>
              <div class="member-info">
                <h4>Quwanishbek Yuldashev</h4>
                <span>Android devoloper</span>
                <p>Life good</p>
                <div class="social">
                  <a href=""><i class="ri-twitter-fill"></i></a>
                  <a href=""><i class="ri-facebook-fill"></i></a>
                  <a href=""><i class="ri-instagram-fill"></i></a>
                  <a href=""> <i class="ri-linkedin-box-fill"></i> </a>
                </div>
              </div>
            </div>
          </div>
          <br>
          <br>

          <div class="col-lg-6 mt-4" data-aos="fade-up" data-aos-delay="600">
            <div class="member d-flex align-items-start">
            <div class="pic"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHgAAAB4CAYAAAA5ZDbSAAAEZ0lEQVR4nO2dIXAUMRSGEScQFchKRGUFAlFR8ZKpQFRUIBEVCAQCgajcGab70lacQCAqKyoQCEQF4gQCiUAgKiqOfbm5ioqKihOHaOi00+nBltt9Sfb/Zn57c/v/k93Ne9nkwQMAAAAAAAAAAAAAAIASVEx7xJ7IVXu29IeGZWDYHxuW86ATwzKwpT8kJ33iao2KaU/7f4MZUDHtUSkbluXAsJwalmktOTmzLAdUygbCjgzias04+V471LvD/k5crWlfV+eh7dGyYTmaW7C3dUTbo2Xt6+wk5OSFYbloMNw/uiAnL7Svt1NQKe9aCPaGyFV7eDY3DBXTnnXyse1wb9yyi/GCtg/ZYln2FcOdGpapLf2htg9ZYkt5ox3uVchcFdp+ZAWxPDMsE+1gr4tK/1zblyyg4uShYfHagd6SkzMqTh5p+5M8lqtCPcw7R7Gwtj9JQ7vjRXNZO1YP8w5d0O54UdunZCGWDxGEOFOWZV/bpyQJz96YR+8fnVNx8lDbr+QIb87a4f2TiOWZtl/JEUNRA7fpBjEsQ+3gamio7VdSEPvHEYRW8zbtH2v7lgy0M1rRDqx2wDujFW3fkoHK0bp2YLUDLkfr2r4lA7G81A6sdsAsL7V9S4aYy5N3CR2mGmAEZw6VsqEdWO2AS9nQ9i0Z8BadOZgHZw4V0565z9cJejrV9iw5UIvOnJSKHShy3AP0gzsAVnRkDtZkdYCYy5ZYVTkHsC66A+DLhg5gS/9WO9Rrt+Z32n5kSdh/QzVcy9VnbR+yJTyPvygG/BXfBzfM5RZJ7c+PLcs+vvBvEcvyyrTz4jWxXL3Wvt5OQk5WDcugwXAH6PNGQFgB8mOOwf7ACo3IwE53HQJ7VQIAAAAAAAAAAAAAABqCeLhE7Detky1y0g815+slyHl3ks7Db1+VNK2TLWK/iXMc5gTtjFYut+/3xy30fWvKH5Or9sjJqrZPSUFOVsOKjZT2yfKWZR9H8cyAduSpabZ535a+YlRfg3i4FFp62sHMVdbJR+Lhkra/atDueJHYvzeRLWifsybE/n3nvl8Ka6ni+xylOZ0Se9L2vRWI/Wbmo3bGaM58qyWNE8tiEznpZ7c8iIrxgnXySdvciJTPCWpUjBcMV98iMDU2/cwiZIzcmTpK+naNZ+7fRU762jndi/C2rG5gCkru7TrMc7s4FbqvJsnMk8POOF0qYsxLp0lUvEL5UdusJBX985h4uGRwa/4fTaJuUOTYFWpb0Z4wHvq56gblINr+9UQ7z1uYPJr1sWignecNwrRI25SsFNWqkBR2hU1NxPJBO9crTFoL5FJRHAdepnhCSiqKYocfNBQaDDiGPTHjXJSei/yxarihchWBEflKtbKFlmAbAftNtYCtky1tA3KXdbKlFjA56WsbkLtUO0wxbNCduyzLgVrABvXnNqRXl8YUqQ0pTpVM3IdW5aJzzYC1L74TQsCZCwFnLgScuRBw5lILGAAAAAAAAAAAAAAAAAAAAACQMr8BLfRpvN2x3EMAAAAASUVORK5CYII=" class="img-fluid" alt=""/></div>
              <div class="member-info">
                <h4>Daston Yuldashev</h4>
                <span>Java devoloper</span>
                <p>Life good</p>
                <div class="social">
                  <a href=""><i class="ri-twitter-fill"></i></a>
                  <a href=""><i class="ri-facebook-fill"></i></a>
                  <a href=""><i class="ri-instagram-fill"></i></a>
                  <a href=""> <i class="ri-linkedin-box-fill"></i> </a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-6 mt-4" data-aos="fade-up" data-aos-delay="700">
            <div class="member d-flex align-items-start">
            <div class="pic"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHgAAAB4CAYAAAA5ZDbSAAAEZ0lEQVR4nO2dIXAUMRSGEScQFchKRGUFAlFR8ZKpQFRUIBEVCAQCgajcGab70lacQCAqKyoQCEQF4gQCiUAgKiqOfbm5ioqKihOHaOi00+nBltt9Sfb/Zn57c/v/k93Ne9nkwQMAAAAAAAAAAAAAAIASVEx7xJ7IVXu29IeGZWDYHxuW86ATwzKwpT8kJ33iao2KaU/7f4MZUDHtUSkbluXAsJwalmktOTmzLAdUygbCjgzias04+V471LvD/k5crWlfV+eh7dGyYTmaW7C3dUTbo2Xt6+wk5OSFYbloMNw/uiAnL7Svt1NQKe9aCPaGyFV7eDY3DBXTnnXyse1wb9yyi/GCtg/ZYln2FcOdGpapLf2htg9ZYkt5ox3uVchcFdp+ZAWxPDMsE+1gr4tK/1zblyyg4uShYfHagd6SkzMqTh5p+5M8lqtCPcw7R7Gwtj9JQ7vjRXNZO1YP8w5d0O54UdunZCGWDxGEOFOWZV/bpyQJz96YR+8fnVNx8lDbr+QIb87a4f2TiOWZtl/JEUNRA7fpBjEsQ+3gamio7VdSEPvHEYRW8zbtH2v7lgy0M1rRDqx2wDujFW3fkoHK0bp2YLUDLkfr2r4lA7G81A6sdsAsL7V9S4aYy5N3CR2mGmAEZw6VsqEdWO2AS9nQ9i0Z8BadOZgHZw4V0565z9cJejrV9iw5UIvOnJSKHShy3AP0gzsAVnRkDtZkdYCYy5ZYVTkHsC66A+DLhg5gS/9WO9Rrt+Z32n5kSdh/QzVcy9VnbR+yJTyPvygG/BXfBzfM5RZJ7c+PLcs+vvBvEcvyyrTz4jWxXL3Wvt5OQk5WDcugwXAH6PNGQFgB8mOOwf7ACo3IwE53HQJ7VQIAAAAAAAAAAAAAABqCeLhE7Detky1y0g815+slyHl3ks7Db1+VNK2TLWK/iXMc5gTtjFYut+/3xy30fWvKH5Or9sjJqrZPSUFOVsOKjZT2yfKWZR9H8cyAduSpabZ535a+YlRfg3i4FFp62sHMVdbJR+Lhkra/atDueJHYvzeRLWifsybE/n3nvl8Ka6ni+xylOZ0Se9L2vRWI/Wbmo3bGaM58qyWNE8tiEznpZ7c8iIrxgnXySdvciJTPCWpUjBcMV98iMDU2/cwiZIzcmTpK+naNZ+7fRU762jndi/C2rG5gCkru7TrMc7s4FbqvJsnMk8POOF0qYsxLp0lUvEL5UdusJBX985h4uGRwa/4fTaJuUOTYFWpb0Z4wHvq56gblINr+9UQ7z1uYPJr1sWignecNwrRI25SsFNWqkBR2hU1NxPJBO9crTFoL5FJRHAdepnhCSiqKYocfNBQaDDiGPTHjXJSei/yxarihchWBEflKtbKFlmAbAftNtYCtky1tA3KXdbKlFjA56WsbkLtUO0wxbNCduyzLgVrABvXnNqRXl8YUqQ0pTpVM3IdW5aJzzYC1L74TQsCZCwFnLgScuRBw5lILGAAAAAAAAAAAAAAAAAAAAACQMr8BLfRpvN2x3EMAAAAASUVORK5CYII=" class="img-fluid" alt=""/></div>
              <div class="member-info">
                <h4>Shodlik Yagmurov</h4>
                <span>Loyihalshtiruvchi</span>
                <p>Life good</p>
                <div class="social">
                  <a href=""><i class="ri-twitter-fill"></i></a>
                  <a href=""><i class="ri-facebook-fill"></i></a>
                  <a href=""><i class="ri-instagram-fill"></i></a>
                  <a href=""> <i class="ri-linkedin-box-fill"></i> </a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-6 mt-4" data-aos="fade-up" data-aos-delay="800">
            <div class="member d-flex align-items-start">
            <div class="pic"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHgAAAB4CAYAAAA5ZDbSAAAEZ0lEQVR4nO2dIXAUMRSGEScQFchKRGUFAlFR8ZKpQFRUIBEVCAQCgajcGab70lacQCAqKyoQCEQF4gQCiUAgKiqOfbm5ioqKihOHaOi00+nBltt9Sfb/Zn57c/v/k93Ne9nkwQMAAAAAAAAAAAAAAIASVEx7xJ7IVXu29IeGZWDYHxuW86ATwzKwpT8kJ33iao2KaU/7f4MZUDHtUSkbluXAsJwalmktOTmzLAdUygbCjgzias04+V471LvD/k5crWlfV+eh7dGyYTmaW7C3dUTbo2Xt6+wk5OSFYbloMNw/uiAnL7Svt1NQKe9aCPaGyFV7eDY3DBXTnnXyse1wb9yyi/GCtg/ZYln2FcOdGpapLf2htg9ZYkt5ox3uVchcFdp+ZAWxPDMsE+1gr4tK/1zblyyg4uShYfHagd6SkzMqTh5p+5M8lqtCPcw7R7Gwtj9JQ7vjRXNZO1YP8w5d0O54UdunZCGWDxGEOFOWZV/bpyQJz96YR+8fnVNx8lDbr+QIb87a4f2TiOWZtl/JEUNRA7fpBjEsQ+3gamio7VdSEPvHEYRW8zbtH2v7lgy0M1rRDqx2wDujFW3fkoHK0bp2YLUDLkfr2r4lA7G81A6sdsAsL7V9S4aYy5N3CR2mGmAEZw6VsqEdWO2AS9nQ9i0Z8BadOZgHZw4V0565z9cJejrV9iw5UIvOnJSKHShy3AP0gzsAVnRkDtZkdYCYy5ZYVTkHsC66A+DLhg5gS/9WO9Rrt+Z32n5kSdh/QzVcy9VnbR+yJTyPvygG/BXfBzfM5RZJ7c+PLcs+vvBvEcvyyrTz4jWxXL3Wvt5OQk5WDcugwXAH6PNGQFgB8mOOwf7ACo3IwE53HQJ7VQIAAAAAAAAAAAAAABqCeLhE7Detky1y0g815+slyHl3ks7Db1+VNK2TLWK/iXMc5gTtjFYut+/3xy30fWvKH5Or9sjJqrZPSUFOVsOKjZT2yfKWZR9H8cyAduSpabZ535a+YlRfg3i4FFp62sHMVdbJR+Lhkra/atDueJHYvzeRLWifsybE/n3nvl8Ka6ni+xylOZ0Se9L2vRWI/Wbmo3bGaM58qyWNE8tiEznpZ7c8iIrxgnXySdvciJTPCWpUjBcMV98iMDU2/cwiZIzcmTpK+naNZ+7fRU762jndi/C2rG5gCkru7TrMc7s4FbqvJsnMk8POOF0qYsxLp0lUvEL5UdusJBX985h4uGRwa/4fTaJuUOTYFWpb0Z4wHvq56gblINr+9UQ7z1uYPJr1sWignecNwrRI25SsFNWqkBR2hU1NxPJBO9crTFoL5FJRHAdepnhCSiqKYocfNBQaDDiGPTHjXJSei/yxarihchWBEflKtbKFlmAbAftNtYCtky1tA3KXdbKlFjA56WsbkLtUO0wxbNCduyzLgVrABvXnNqRXl8YUqQ0pTpVM3IdW5aJzzYC1L74TQsCZCwFnLgScuRBw5lILGAAAAAAAAAAAAAAAAAAAAACQMr8BLfRpvN2x3EMAAAAASUVORK5CYII=" class="img-fluid" alt=""/></div>
              <div class="member-info">
                <h4>Jasur Tajibayev</h4>
                <span>Shoir</span>
                <p>Life good</p>
                <div class="social">
                  <a href=""><i class="ri-twitter-fill"></i></a>
                  <a href=""><i class="ri-facebook-fill"></i></a>
                  <a href=""><i class="ri-instagram-fill"></i></a>
                  <a href=""> <i class="ri-linkedin-box-fill"></i> </a>
                </div>
              </div>
            </div>
          </div>


        </div>

      </div>
    </section><!-- End Team Section -->
