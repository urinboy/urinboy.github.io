    <!--text----------------------->
    <div class="text-container">
		<p>Hello,</p>
		<p>I&#8217;M RASULBEK</p>
		<p>Freelancing with Designer <br>& Devolper</p>
		<button class="hire-btn">Hire me</button>
		<button class="down-cv">Download CV</button>
	</div>
	<!--model---------------------->
<img alt="model" class="model" src="assets/img/rasul.png">
