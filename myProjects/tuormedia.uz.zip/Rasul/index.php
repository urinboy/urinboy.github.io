<?php 
    $title = 'Asosiy sahifa ';  
    include 'inc/header.php';
    include 'inc/hero.php';
?>
	<div class="about-container" id="about">
		<!--img-->
<img src="assets/img/about-img-rasul.png"/>
		<!--about-me-text-->
		<div class="about-text">
		<p>About Me</p>
		<p>Devolper & Designer</p>
		<p>Hello,My name is Touseeq Ijaz. I am a Devolper and also a Designer.If you have asany Project or if you want make a software for your bisnes conatact me.I make as soon as possibale.You really like my work,if you don&#8217;t i change this until you like I give you seticfaction result.</p>
		<p>I am a Devolper and also a Designer.If you have asany Project or if you want make a software for your bussniess conatact me.I make your project as soon as possible.</p>
		<button>Hire Me</button>
		<button>Download CV</button>
		</div>
	</div>
	<!--services-container---------------------------->
	<div class="services" id="servises">
		<!--text-->
		<div class="services-text ">
			<p>Services</p>
			<p>Qualites Requaid</p>
			<p>if you want make a software for your bussniess conatact me.I make as soon as possibale.You really like my work, if you don&#8217;t i change this until you like if you want make a software for your bussniess conatact me.I make as soon</p>
		</div>
		<div class="box-container">
		<!--1------------->
			<div class="box-1">
			<span>1</span>
			<p class="heading">Web Design</p>
			<p class="details">if you want make a software for your bussniess conatact me.I make as soon as possibale.You really like my work, if you don&#8217;t i change this until you like if you want.</p>
			<button>Read More</button>
			</div>
	   <!--2------------->
			<div class="box-2">
			<span>2</span>
			<p class="heading">Web Devoloment</p>
			<p class="details">if you want make a software for your bussniess conatact me.I make as soon as possibale.You really like my work, if you don&#8217;t i change this until you like if you want.</p>
			<button>Read More</button>
			</div>
		<!--3------------->
			<div class="box-3">
			<span>3</span>
			<p class="heading">Security SEO</p>
			<p class="details">if you want make a software for your bussniess conatact me.I make as soon as possibale.You really like my work, if you don&#8217;t i change this until you like if you want.</p>
			<button>Read More</button>
			</div>
		</div>
	</div>
    <!--if you have any project in your mind contact me-->
	<div class="contact-me" id="contact">
		<p>If You Have Any Project In Your Mind ?</p>
		<button>Contact me</button>
	</div>






<?php include 'inc/footer.php';?>