<?php
$page_id = 1;
$title = "Bosh sahifa";
$site_name = "TUORMedia.uz";
include "includes/header.php";
?>
    <!-- ======= Why Us Section ======= -->
    <section id="why-us" class="why-us">
      <div class="container-fluid">

        <div class="row">

          <div class="col-lg-5 align-items-stretch video-box" style='background-image: url("styles/img/5tashabbus.jpg");margin-left:20px;' data-aos="fade-right">
            <a href="https://www.youtube.com/watch?v=cHeiv3Giyfk" class="venobox play-btn mb-4" data-vbtype="video" data-autoplay="true"></a>
          </div>

          <div class="col-lg-6 d-flex flex-column justify-content-center align-items-stretch" data-aos="fade-left">

            <div class="content">
              <h3>Yoshlar ma'naviyatini yuksaltirish va ularning bosh vaqtini mazmunli tashlik etish bo'yicha <strong>5 ta muhim tashabbus!</strong></h3>
              <p>

              </p>
            </div>

            <div class="accordion-list">
              <ul>
                <li data-aos="fade-up" data-aos-delay="100">
                  <a data-toggle="collapse" class="collapsed" href="#accordion-list-1"><span>01</span>- tashabbus. San'at va madaniyat <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="accordion-list-1" class="collapse" data-parent=".accordion-list">
                    <p>
                        Yoshlarning <b>musiqa, rassomlik, adabiyot, teatr va san'atning </b>boshqa turlariga qiziqishlarini oshirishga, istedoni yuzaga chiqarishga xizmat qiladi.
                    </p>
                  </div>
                </li>

                <li data-aos="fade-up" data-aos-delay="200">
                  <a data-toggle="collapse" href="#accordion-list-2" class="collapsed"><span>02</span>- tashabbus. Sport <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="accordion-list-2" class="collapse" data-parent=".accordion-list">
                    <p>
                        Yoshlarni jismoniy chiniqtirish, ularning <b>sport</b> sohasida qobiliyatini namoyish qilishlari uchunzarur sharoitlarni yaratishga yo'naltirilgan.                  </p>
                  </div>
                </li>

                <li data-aos="fade-up" data-aos-delay="300">
                  <a data-toggle="collapse" href="#accordion-list-3" class="collapsed"><span>03</span>- tashabbus. Axborot texnologiyalari <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="accordion-list-3" class="collapse" data-parent=".accordion-list">
                    <p>
                        Aholi va yoshlar o'rtasida  <b>Kompyuter texnologiyalari va internet</b>dan samarali foydalanishni tashkil etishga qaratish.                    </p>
                  </div>
                </li>
                <li data-aos="fade-up" data-aos-delay="400">
                  <a data-toggle="collapse" href="#accordion-list-4" class="collapsed"><span>04</span>- tashabbus. Mutoala <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="accordion-list-4" class="collapse" data-parent=".accordion-list">
                    <p>
                        Yoshlar ma'naviyatini yuksaltirish, ular o'rtasida <b> kitobxonlikni</b> keng targ'ib qilish bo'yicha tizimli ishlarni tashkil etishga yo'naltirilgan.
                    </p>
                  </div>
                </li>
                <li data-aos="fade-up" data-aos-delay="500">
                  <a data-toggle="collapse" href="#accordion-list-5" class="collapsed"><span>05</span>- tashabbus. Xotin qizlar <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="accordion-list-5" class="collapse" data-parent=".accordion-list">
                    <p>
                        Xotin-qizlarni <b>ish bilan ta'minlash</b> masalalarini nazarda tutadi.
                    </p>
                  </div>
                </li>

              </ul>
            </div>

          </div>

        </div>

      </div>
    </section><!-- End Why Us Section -->


<!-- ======= About Us Section ======= -->
  <section id="about" class="about">
      <div class="container" data-aos="fade-up">
        <div class="section-title">
          <h2>Biz haqimizda</h2>
          <p>
          </p>
        </div>

        <div class="row content">
          <div class="col-lg-6"  data-aos="fade-right">
            <p style="margin-left:-60px"><img src="styles/img/favicon.png"></p>
            
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0">
                  <!-- ======= Clients Section ======= -->
    <section id="clients" class="clients">
      <div class="container" data-aos="zoom-in">

        <div class="owl-carousel clients-carousel">
          <img src="styles/img/clients/client-1.png" alt="">
          <img src="styles/img/clients/client-2.png" alt="">
          <img src="styles/img/clients/client-3.png" alt="">
          <img src="styles/img/clients/client-4.png" alt="">
          <img src="styles/img/clients/client-5.png" alt="">
          <img src="styles/img/clients/client-6.png" alt="">
          <img src="styles/img/clients/client-7.png" alt="">
          <img src="styles/img/clients/client-8.png" alt="">
        </div>

      </div>
    </section><!-- End Clients Section -->

            <p data-aos="fade-left">
                Sizning kelajagingiz biz bilan birga birinchi qadamlardan boshlanadi. Eng yaxshi investitsiya bu kelajak uchun bilim olishga sariflangan investitsiyadir.
                Bilim bo'lsa pul topiladi. bu siznning hayotingizni tubdan o'zgartitirishga biz kafolat beramiz. 
              Siz o'zingiz istagan yo'nalishlarda kurslarimizga yozilib yangi kasb egasiga aylaning.</p>
            <div class="icon" style="text-align:right;">
            <a href="#" class="btn-learn-more">Batafsil <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAUklEQVRIiWNgGAUjEwhEXysQiL3WT6oc8YbHXPsvEHPtP7pB+OSItyD2Wj/cEDSD8MmNWjKELaGpBaOG099wDEPQiwo8cqRbgquwwyM3CkYoAABT0v6x8rYRKwAAAABJRU5ErkJggg=="/></a></div>

          </div>
        </div>

      </div>
    </section><!-- End About Us Section -->

    
    <?php include "courses/kurs.php"; ?>
    
    <!-- ======= Cta Section ======= -->
    <section id="cta" class="cta">
      <div class="container">

        <div class="row" data-aos="zoom-in">
          <div class="col-lg-9 text-center text-lg-left">
            <h3>Takliflar va hamkorlik</h3>
            <p> Agarda sizda taklifalar vca hamkorlik qilish niyatingiz bo'lsa biz bilan bog'laning va biz bilan birgalikda kelajak uchun qadam tashlanag.</p>
          </div>
          <div class="col-lg-3 cta-btn-container text-center">
            <a class="cta-btn align-middle" href="#">Taklif berish</a>
          </div>
        </div>

      </div>
    </section><!-- End Cta Section -->
<!-- ===== Loyihalar ===== -->
<?php include "includes/loyihalar/index.php"; ?>

<!-- ===== Loyihalar ===== -->
<?php include "team/team.php"; ?>

    <!-- ======= Pricing Section ======= -->
    <section id="pricing" class="pricing">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Boshlang'ich Kurs Narxlari</h2>
          <p></p>
        </div>

        <div class="row">

          <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="100">
            <div class="box">
              <h3 id="oddiy"><i class="icofont-wallet"></i> Oddiy </h3>
              <h4><span>oy /</span> 50 000   <sup> UZS</sup></h4><br>
              <ul>
                <li><i class="icofont-computer"></i> Kompyuter  </li>
                <li><i class="bx bxl-google"></i>Google</li>
                <li><i class="bx bxl-windows"></i>Office</li>
                <li class="na"><i class="bx bxl-html5"></i> HTML 5</li>
                <li class="na"><i class="bx bxl-css3"></i> CSS 3  </li>
                <li class="na"><i class="bx bxl-javascript"></i> Javasrcipt  </li>
                <li class="na"><i class="bx bxl-bootstrap"></i> Boootstrap  </li>
                <li class="na"><i class="bx bxl-wordpress"></i> WordPress  </li>
                <li class="na"><i class="icofont-evernote"></i> PHP  </li>
                <li class="na"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAABg0lEQVRIie2UrU4DQRSFR1QiEIgKRB8BgSEBeu8oBO9AHQGF4AE2JOyZFhIkEoFEIhGICgQCgahANCHdM7QViIqKikWUwHbbbn82OG5yxCS755u5c+4Y8195S6rctIjuFewpGCvYV7BhwVupttZzmyvYk5BQsPsN+JXjp9Q6xeUB8BUFm1LrFBXR0xgAjAW+khcwZpoLIEFcEHBP4CuTlAaU4Y8tosCGPJnZLgk6KwrWZ+165ATOnybWPYEvTQc4Xi1irmBcDv1Rcm0d76YCFGwsCOiVz9530snKAgwmmAw05LOCj0lZRDe7jrsKPqT/yQL0Ux/Xy2F7yzrepQHf0EkbygSMtMiiZRMTPJ+yWiTg9UhCQn+w6KVbRDfTAZdc08STkIrgPGpI0FydCjDGGKl1ij+D5dqHY7lPD1/4sS/wIo7bEsSFTPPxlv3BUzEn4FXgSwo28gGC5qqCflJSxEUXCnalys2lAcYML14cr9TxRcHmUP7Ngrdy3trIZf5fxhjzBawgcQBNMbKqAAAAAElFTkSuQmCC"/> Python  </li>
              </ul>
              <div class="btn-wrap">
              <a href="#" class="btn-buy">Sotib olish</a>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-4 mt-md-0" data-aos="fade-up" data-aos-delay="200">
            <div class="box featured">
              <h3 id="boshlangich"><i class="icofont-wallet"></i> Boshlang'ich</h3>
              <h4><span>oy /</span> 100 000 <sup>UZS</sup></h4>
              <ul>
                <li><i class="icofont-computer"></i> Kompyuter  </li>
                <li><i class="bx bxl-google"></i>Google</li>
                <li><i class="bx bxl-windows"></i>Office</li>
                <li><i class="bx bxl-html5"></i> HTML 5</li>
                <li><i class="bx bxl-css3"></i> CSS 3  </li>
                <li class="na"><i class="bx bxl-javascript"></i> Javasrcipt  </li>
                <li class="na"><i class="bx bxl-bootstrap"></i> Boootstrap  </li>
                <li class="na"><i class="bx bxl-wordpress"></i> WordPress  </li>
                <li class="na"><i class="icofont-evernote"></i> PHP  </li>
                <li class="na"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAABg0lEQVRIie2UrU4DQRSFR1QiEIgKRB8BgSEBeu8oBO9AHQGF4AE2JOyZFhIkEoFEIhGICgQCgahANCHdM7QViIqKikWUwHbbbn82OG5yxCS755u5c+4Y8195S6rctIjuFewpGCvYV7BhwVupttZzmyvYk5BQsPsN+JXjp9Q6xeUB8BUFm1LrFBXR0xgAjAW+khcwZpoLIEFcEHBP4CuTlAaU4Y8tosCGPJnZLgk6KwrWZ+165ATOnybWPYEvTQc4Xi1irmBcDv1Rcm0d76YCFGwsCOiVz9530snKAgwmmAw05LOCj0lZRDe7jrsKPqT/yQL0Ux/Xy2F7yzrepQHf0EkbygSMtMiiZRMTPJ+yWiTg9UhCQn+w6KVbRDfTAZdc08STkIrgPGpI0FydCjDGGKl1ij+D5dqHY7lPD1/4sS/wIo7bEsSFTPPxlv3BUzEn4FXgSwo28gGC5qqCflJSxEUXCnalys2lAcYML14cr9TxRcHmUP7Ngrdy3trIZf5fxhjzBawgcQBNMbKqAAAAAElFTkSuQmCC"/> Python  </li>
              </ul>
              <div class="btn-wrap">
              <a href="#" class="btn-buy">Sotib olish</a>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="300">
            <div class="box">
              <h3 id="ortacha"><i class="icofont-wallet"></i> O'rta daraja</h3>
              <h4><span>oy /</span> 150 000 <sup>UZS</sup></h4>
              <ul>
                <li><i class="icofont-computer"></i> Kompyuter  </li>
                <li><i class="bx bxl-google"></i>Google</li>
                <li><i class="bx bxl-windows"></i>Office</li>
                <li><i class="bx bxl-html5"></i> HTML 5</li>
                <li><i class="bx bxl-css3"></i> CSS 3  </li>
                <li><i class="bx bxl-javascript"></i> Javasrcipt  </li>
                <li><i class="bx bxl-bootstrap"></i> Boootstrap  </li>
                <li class="na"><i class="bx bxl-wordpress"></i> WordPress  </li>
                <li class="na"><i class="icofont-evernote"></i> PHP  </li>
                <li class="na"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAABg0lEQVRIie2UrU4DQRSFR1QiEIgKRB8BgSEBeu8oBO9AHQGF4AE2JOyZFhIkEoFEIhGICgQCgahANCHdM7QViIqKikWUwHbbbn82OG5yxCS755u5c+4Y8195S6rctIjuFewpGCvYV7BhwVupttZzmyvYk5BQsPsN+JXjp9Q6xeUB8BUFm1LrFBXR0xgAjAW+khcwZpoLIEFcEHBP4CuTlAaU4Y8tosCGPJnZLgk6KwrWZ+165ATOnybWPYEvTQc4Xi1irmBcDv1Rcm0d76YCFGwsCOiVz9530snKAgwmmAw05LOCj0lZRDe7jrsKPqT/yQL0Ux/Xy2F7yzrepQHf0EkbygSMtMiiZRMTPJ+yWiTg9UhCQn+w6KVbRDfTAZdc08STkIrgPGpI0FydCjDGGKl1ij+D5dqHY7lPD1/4sS/wIo7bEsSFTPPxlv3BUzEn4FXgSwo28gGC5qqCflJSxEUXCnalys2lAcYML14cr9TxRcHmUP7Ngrdy3trIZf5fxhjzBawgcQBNMbKqAAAAAElFTkSuQmCC"/> Python  </li>
              </ul>
              <div class="btn-wrap">
              <a href="#" class="btn-buy">Sotib olish</a>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="400">
            <div class="box">
              <span class="advanced">Malakali</span>
              <h3 id="yuqori"><i class="icofont-wallet"></i> Yuqori daraja</h3>
              <h4><span>oy /</span> 200 000 <sup>UZS</sup></h4>
              <ul>
                <li><i class="icofont-computer"></i> Kompyuter  </li>
                <li><i class="bx bxl-google"></i>Google</li>
                <li><i class="bx bxl-windows"></i>Office</li>
                <li><i class="bx bxl-html5"></i> HTML 5</li>
                <li><i class="bx bxl-css3"></i> CSS 3  </li>
                <li><i class="bx bxl-javascript"></i> Javasrcipt  </li>
                <li><i class="bx bxl-bootstrap"></i> Boootstrap  </li>
                <li><i class="bx bxl-wordpress"></i> WordPress  </li>
                <li><i class="icofont-evernote"></i> PHP  </li>
                <li><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAABg0lEQVRIie2UrU4DQRSFR1QiEIgKRB8BgSEBeu8oBO9AHQGF4AE2JOyZFhIkEoFEIhGICgQCgahANCHdM7QViIqKikWUwHbbbn82OG5yxCS755u5c+4Y8195S6rctIjuFewpGCvYV7BhwVupttZzmyvYk5BQsPsN+JXjp9Q6xeUB8BUFm1LrFBXR0xgAjAW+khcwZpoLIEFcEHBP4CuTlAaU4Y8tosCGPJnZLgk6KwrWZ+165ATOnybWPYEvTQc4Xi1irmBcDv1Rcm0d76YCFGwsCOiVz9530snKAgwmmAw05LOCj0lZRDe7jrsKPqT/yQL0Ux/Xy2F7yzrepQHf0EkbygSMtMiiZRMTPJ+yWiTg9UhCQn+w6KVbRDfTAZdc08STkIrgPGpI0FydCjDGGKl1ij+D5dqHY7lPD1/4sS/wIo7bEsSFTPPxlv3BUzEn4FXgSwo28gGC5qqCflJSxEUXCnalys2lAcYML14cr9TxRcHmUP7Ngrdy3trIZf5fxhjzBawgcQBNMbKqAAAAAElFTkSuQmCC"/> Python  </li>
              </ul>
              <div class="btn-wrap">
                <a href="#" class="btn-buy">Sotib olish</a>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Pricing Section -->

<?php include "team/qustions.php"; ?>




    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Biz bilan bog'lanish</h2>
        </div>

        <div class="row mt-1 d-flex justify-content-end" data-aos="fade-right" data-aos-delay="100">

          <div class="col-lg-5">
            <div class="info">
              <div class="address">
                <i class="icofont-google-map"></i>
                <h4>Manzil:</h4>
                <p>O'zbekiston, Qoraqalpog'iston Respublikasi, Taxiatosh tumani, Keneges OFY</p>
              </div>

              <div class="email">
                <i class="icofont-envelope"></i>
                <h4>Email:</h4>
                <p>urinboytursunboev@gmail.com</p>
              </div>

              <div class="phone">
                <i class="icofont-phone"></i>
                <h4>Tel:</h4>
                <p>+998 91 373 11 96</p>
              </div>

            </div>

          </div>

          <div class="col-lg-6 mt-5 mt-lg-0" data-aos="fade-left" data-aos-delay="100">

          <form action="contact.php" method="post" role="form" class="php-email-form">
          
          <?php 

            if (isset($_GET['error'])) {
                echo '<div class="alert alert-danger">'.$msg.'</div>';
            }
                if (isset($_GET['success'])) {
                    echo '<div class="alert alert-success">'.$msg.'</div>';
                }
          ?>
 
             <div class="form-row">
                  
                <div class="col-md-6 form-group">
                  <input type="text" name="contact_username" class="form-control" placeholder="Ism"/>
                </div>
                <div class="col-md-6 form-group">
                  <input type="email" class="form-control" name="contact_email" placeholder="address@tuormedia.uz" />
                </div>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="subject" placeholder="Mavzu" />
                </div>
                <div class="form-group">
                    <textarea class="form-control mb-2" name="message" rows="8"   placeholder="Xabar"></textarea>
                </div>
        <!-- <div class="mb-3">
                <div class="loading">Yuborilmoqda</div>
                <div class="error-message"></div>
                <div class="sent-message">Raxmat sizning xabaringiz yuborildi!</div> 
              </div> -->

              <div class="text-center"><button type="submit" name="submit">Xabarni yuborish</button></div>
            </form>

          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->




<?php
include "includes/footer.php";
?>