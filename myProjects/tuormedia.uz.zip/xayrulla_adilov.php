<?php

$page_id = '';
$page_lang = "uz";
$url = "http://tuormedia.uz/mp3lar.php";
$category = "Musiqalar";
$title = "Xayrulla Adilov";
$site_name = "TUORMedia.uz";
$description = "O'zimizning eng sara Qo'shiqlar";
$keywords = " O'zimizning eng sara Qo'shiqlar, tuormedia.uz, She'riyat, O'zimizning eng sara, Qo'shiqlar, Shoir, ijodkor 2020";
$local = "Taxiatosh tumani, Keneges OFY";
$image = "http://tuormedia.uz/styles/img/favicon.png";

include "includes/header.php";
?>
<style>
  .vid{
    width:520px;
    height:270px;
  }
</style>

<object width="100%" height="650px" data="xayrush.html"></object>
    <!-- ======= Team Section ======= -->
    <section id="team" class="team section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Honanda Ijodi</h2>
          <p></p>
        </div>

        <div class="row">
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
            <div class="member d-flex align-items-start">
               <img src="http://tuormedia.uz/styles/img/portfolio/Logopit.png" width="100%" height="100%" style="border-radius:6px;" alt="Xayrulla Adilov"/>
            </div>
          </div>
          <div class="col-lg-6 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="100">
            <div class="member d-flex align-items-start">
                
                <ol>
                <h4>Eng sara taronalar</h4><br>
          
                    <li> Kuladi</li>
                    <li> Jonim (new version)</li>
                    <li> Jonim</li>
                    <li> Uzun</li>
                    <li> Eslama</li>
                    <li> Yugura yugura</li>
                </ol>
            </div>
          </div>
          <div class="col-lg-6 mt-4" data-aos="fade-up" data-aos-delay="200">
            <div class="member d-flex align-items-start">
            <iframe class="vid" src="https://www.youtube.com/embed/1fR7DFDaixU" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>                        
          </div>
      </div>

      <div class="col-lg-6 mt-4" data-aos="fade-up" data-aos-delay="300">
            <div class="member d-flex align-items-start">
              <iframe class="vid" src="https://www.youtube.com/embed/E5a4r9nxAdk" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
          </div>
          <div class="col-lg-6 mt-4" data-aos="fade-up" data-aos-delay="400">
            <div class="member d-flex align-items-start">
              <iframe class="vid" src="https://www.youtube.com/embed/6jeH-AXl_RI" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
          </div>

          <div class="col-lg-6 mt-4" data-aos="fade-up" data-aos-delay="300">
            <div class="member d-flex align-items-start">
            <iframe class="vid" src="https://www.youtube.com/embed/Vmerv4D6seI" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
          </div>
          <div class="col-lg-6 mt-4" data-aos="fade-up" data-aos-delay="400">
            <div class="member d-flex align-items-start">
              <iframe class="vid" src="https://www.youtube.com/embed/3EfUQu_5-XE" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
          </div>


        </div>
      </div>
    </section><!-- End Team Section -->

                  
<script src="/player.js"></script>

<?php
include "includes/footer.php";
?>