<?php
$page_id = '';
$page_url = "/kiritish.php";
$title = "Bazaga kiritish";
$site_name = "TUORMedia.uz";
include "includes/header.php";
?>

    <!-- ======= Login Section ======= -->
    <section id="login" class="blog">
      <div class="container">
                    
            <div class="row" data-aos="fade-up" data-aos-delay="100">
                <div class="col-md-4 offset-md-4 form-div">
                <form method="post" action="insert.php">
                    <div class="section-title" data-aos="fade-up" data-aos-delay="300">
                     <h3 class="text-center">Bazaga kiritish</h3>
                    </div>
                   <?php if(count($errors) > 0): ?>
					<div class="alert <?php 
					if($statement->execute()){ 
						echo $alert['alert-class'] = "alert-success";
					}else {
						echo $alert['alert-class'] = "alert-danger";
					} ?>">
                     <?php foreach($errors as $error): ?>
                        <li style="list-style-type:none;"><i class="bx bx-error-circle"> </i>    <?php echo $error; ?></li>
                        <?php endforeach; ?>
                    </div> 
                    <?php endif; ?>

                    <div class="form-group" data-aos="fade-up" data-aos-delay="400">
                        
                    <label for="firstName">Ismingiz:</label>
                    <input type="text" name="first_name" id="firstName" placeholder="Ismingizni kiriting" value="<?php echo $username; ?>" class="form-control form-control-lg">
                    </div>
                    <div class="form-group" data-aos="fade-up" data-aos-delay="600">
                    <label for="lastName">Familiya:</label>
                    <input type="text" name="last_name" id="lastName" placeholder="Familiyani kiriting" class="form-control form-control-lg">
                    </div>
                    <div class="form-group" data-aos="fade-up" data-aos-delay="500">
                    <label for="emailAddress">Email Address:</label>
                    <input type="email" name="email" id="emailAddress" placeholder="Elektron manzilni kiriting" class="form-control form-control-lg">
                    </div>
                    <div class="form-group" data-aos="fade-up" data-aos-delay="700">
                    <button type="submit" name="submit" class="btn btn-primary btn-block btn-lg">Qo'shib qo'yish</button>
                    </div>
                </form>
                </div>
            </div>
      </div>
    </section><!-- End Login Section -->

	<?php include "includes/footer.php"; ?>