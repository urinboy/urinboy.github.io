function Clear() {
 document.getElementById("output").innerHTML = "0";
}
function rZero() {
  let value = document.getElementById("output").innerHTML;
  if(value ==="0"){
    value = " ";
    document.getElementById("output").innerHTML = value;
  }
}
function perc() {
  let value = document.getElementById("output").innerHTML;
  value = value / 100;
  document.getElementById("output").innerHTML = value;
}
function output(value) {
  rZero();
  document.getElementById("output").innerHTML += value;
}
function solve() {
  rZero()
  let equastion = document.getElementById("output").innerHTML;
  let solved = eval(equastion);
  document.getElementById("output").innerHTML = solved;
}