<?php
$ismErr = $familiyaErr = $yoshErr = $emailErr = $telErr = $addressErr = "";
$ism = $familiya = $yosh = $email = $tel = $address = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
 
  function val($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
   
  $ism = val($_POST["ism"]);
  $familiya = val($_POST["familiya"]);
  $yosh = val($_POST["yosh"]);
  $email = val($_POST["email"]);
  $tel = val($_POST["tel"]);
  $address = val($_POST["address"]);


  if (empty($_POST["ism"])) {
    $ismErr = "Ismni kiriting!";
  } else if (empty($_POST["familiya"])) {
    $familiyaErr = "Familyani kiriting!";
  } else if (empty($_POST["yosh"])) {
    $yoshErr = "Yoshni kiriting!";
  } else if (empty($_POST["email"])) {
    $emailErr = "Email pochtani kiriting!";
  } else if (empty($_POST["tel"])) {
    $telErr = "Telefon raqamni kiriting!";
  } else if (empty($_POST["address"])) {
    $addressErr = "Tug`ilgan joyni kiriting!";
  } else {
    $ism = $_POST['ism'];
    $familiya = $_POST['familiya'];
    $yosh = $_POST['yosh'];
    $email = $_POST['email'];
    $tel = $_POST['tel'];
    $address = $_POST['address'];
      header("Location: home.php");
           
  }
} 

?>