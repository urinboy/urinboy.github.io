<nav>
<input type="checkbox" id="check">
<label for="check" class="checkbtn">
<i class="fa fa-bars"></i>
</label>
<labe class="logo">TUORMedia</lebel>
<ul>
<li><a href="/form">Form</a></li>
<li><a href="home.php">Profil</a></li>
<li><a href="about.php">Info</a></li>
</ul>
</nav>