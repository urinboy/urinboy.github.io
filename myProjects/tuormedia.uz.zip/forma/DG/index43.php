<?php
$title = "Ro`yxatdan o`tish";
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equive="X-UA-Comptible" content="ie=edge">
        <title><?= $title; ?></title>
        <link rel="stylesheet" href="styles.css">
        
    </head>
    <body>
        <div class="container">
            <h1><?= $title; ?></h1>
            <form action="info.php" method="post">
            <div class="input-group">
                <input type="text" name="ism" id="ism" placeholder=" ">
                <label form="ism">Ism</label>
            </div>
            <div class="input-group">
                <input type="text" name="familiya" id="familiya" placeholder=" ">
                <label form="familiya">Familiya</label>
            </div>
            <div class="input-group">
                <input type="number" name="yosh" id="yosh" placeholder=" ">
                <label form="yosh">Yosh</label>
            </div>
            <div class="input-group">
                <input type="email" name="email" id="email" placeholder=" ">
                <label form="email">Email</label>
            </div>
            <div class="input-group">
                <input type="number" name="tel" id="tel" placeholder=" ">
                <label form="tel">Telefon raqam</label>
            </div>
            <div class="input-group">
                <input type="text" name="address" id="address" placeholder=" ">
                <label form="address">Tug'ilgan joy</label>
            </div>
            <button type="submit" name="submit" id="submit" class="btn">Yuborish</button>
            </form>
        </div>
        
    </body>
</html>