
  </main><!-- End #main -->

<!-- ======= Footer ======= -->
<footer id="footer">
    <?php 
    if($page_id == 1){
        include "includes/footmenu.php";
    } 
    ?>
<div class="container">
  <div class="copyright">
    &copy; 2020 - <?= date("Y"); ?> <strong>TUORM<span>edia.uz</span></strong> 
  </div>
  <div class="credits">
    Sayt yaratuvchisi <a href="https://t.me/tuormedia"><b>O'rinboy Tursunboyev</b></a>
  </div>
</div>
</footer><!-- End Footer -->
<!-- START WWW.UZ TOP-RATING --><SCRIPT language="javascript" type="text/javascript">
<!--
top_js="1.0";top_r="id=45675&r="+escape(document.referrer)+"&pg="+escape(window.location.href);document.cookie="smart_top=1; path=/"; top_r+="&c="+(document.cookie?"Y":"N")
//-->
</SCRIPT>
<SCRIPT language="javascript1.1" type="text/javascript">
<!--
top_js="1.1";top_r+="&j="+(navigator.javaEnabled()?"Y":"N")
//-->
</SCRIPT>
<SCRIPT language="javascript1.2" type="text/javascript">
<!--
top_js="1.2";top_r+="&wh="+screen.width+'x'+screen.height+"&px="+
(((navigator.appName.substring(0,3)=="Mic"))?screen.colorDepth:screen.pixelDepth)
//-->
</SCRIPT>
<SCRIPT language="javascript1.3" type="text/javascript">
<!--
top_js="1.3";
//-->
</SCRIPT>
<SCRIPT language="JavaScript" type="text/javascript">
<!--
top_rat="&col=340F6E&t=ffffff&p=BD6F6F";top_r+="&js="+top_js+"";document.write('<img src="https://cnt0.www.uz/counter/collect?'+top_r+top_rat+'" width=0 height=0 border=0 />')//-->
</SCRIPT><NOSCRIPT><IMG height=0 src="https://cnt0.www.uz/counter/collect?id=45675&pg=http%3A//uzinfocom.uz&col=340F6E&t=ffffff&p=BD6F6F" width=0 border=0 /></NOSCRIPT><!-- FINISH WWW.UZ TOP-RATING -->  
<a href="#" class="back-to-top"><i class="ri-arrow-up-line"></i></a>
<div id="preloader"></div>
<?php require "links/scr.php"; ?>
</body>
</html>