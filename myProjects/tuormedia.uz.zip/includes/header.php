<!DOCTYPE html>
<html lang="<?php echo $page_lang; ?>">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
<meta http-equiv='refresh' content='0;URL=http://admin.tuormedia.uz'>
  <title><?php echo $title." - ".$site_name; ?> </title>  
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
  <meta name="description" content="<?php echo $description; ?>">
  <meta content="<?php echo $keywords; ?>" name="keywords">
  <meta property="og:type" content="article">
  <meta property="og:site_name" content="<?php echo $site_name; ?>">
  <meta property="og:title" content="<?php echo $title; ?>">
  <meta property="og:description" content="<?php echo $description; ?>">
  <meta property="og:url" content="<?php echo $url; ?>">
  <meta property="og:locale" content="<?php echo $local; ?>">
  <meta property="og:image" content="<?php echo $image; ?>">
  <meta name="HandheldFriendly" content="true">
  <meta name="MobileOptimized" content="width">
  <meta content="yes" name="apple-mobile-web-app-capable">
  <meta name="telegram:channel" content="@tuormedia_uz">

<?php include "styles/style.php"; ?>
</head>

<body>
<?php 
$css1 ="";
$css2 ="";
if($page_id != 1){
$css1 = "topbar-inner-pages";
$css2 = "header-inner-pages";
}
?>
  <!-- ======= Top Bar ======= -->
  <div id="topbar" class="d-none d-lg-flex align-items-center fixed-top <?php echo $css1; ?>">
    <div class="container d-flex align-items-center">
      <div class="contact-info mr-auto">
        <ul>
          <li><i class="icofont-envelope"></i><a href="mailto:urinboytursunboev@gmail.com">urinboytursunboev@gmail.com</a></li>
          <li><i class="icofont-phone"></i> +998 91 373 11 96</li>
          <li><i class="icofont-clock-time icofont-flip-horizontal"></i> Dushanba - Juma   09:00 - 17:00</li>
        </ul>
      </div>
      <div class="cta">
        <a href="#" class="scrollto">Boshlash</a>
      </div>
    </div>
  </div>
  <!-- ======= Header ======= -->
  <style>
    
@import url('https://fonts.googleapis.com/css2?family=Exo+2:wght@700&family=Fredoka+One&display=swap');
.logo{
  margin-top:23px;
  font-family: 'Exo 2', sans-serif;
  font-family: 'Fredoka One', cursive;
}
    </style>
  <header id="header" style="margin-bottom:90px;"class="fixed-top <?php echo $css2; ?>">
    <div class="container d-flex align-items-center">
        <h3 class="logo mr-auto"><a href="/" class="scrollto"> 
        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-school" width="40" height="40" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
        <path d="M22 9l-10 -4l-10 4l10 4l10 -4v6" />
        <path d="M6 10.6v5.4a6 3 0 0 0 12 0v-5.4" />
        </svg> TUORM<span class="logo">edia.uz</span></a></h3>
        <!-- <Uncomment below if you prefer to use an image logo>
        <a href="#header" class="logo mr-auto scrollto">
        <img src="assets/img/logo.png" alt="" class="img-fluid">
        </a> -->
        <?php include "includes/nav.php"; ?>      
    </div>
  </header><!-- End Header -->
    <?php 
    if($page_id == 1) {
    include "includes/hero.php"; 
    }    
    ?>
  <main id="main">
    <?php
    if($page_id != 1) {
      include "includes/bread.php";
    }
    if($page_id == 1) {
    include "includes/ibox.php"; 
    }
    ?>