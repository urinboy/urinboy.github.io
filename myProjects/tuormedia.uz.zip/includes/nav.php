<nav class="nav-menu d-none d-lg-block" style="margin-bottom:-10px;">
        <ul>
          <li class="active"><a href="/"><i class="icofont-home"></i> Asosiy</a></li>
<li class="drop-down"><a><i class="bx bxs-devices"> </i> Kurslar</a>
          <ul>
                <li><a href="/courses.php"><i class="bx bxs-devices"></i> Barchasi haqida</a> </li>
                <li><a href="/users/course/pc.php"><i class="icofont-computer"></i> Kompyuter savodxonligi</a> </li>
                <li><a href="#"><i class="bx bxl-google"></i> Google Platformasi</a></li>
                <li class="drop-down"><a><i class="bx bxl-windows"></i> MicroSoft Office</a>
                    <ul>     
                     <li><a href="#"><i class="bx bxl-word"></i> MS Word</a></li>
                     <li><a href="#"><i class="bx bxl-exsel"></i> MS Exsel  </a></li>
                     <li><a href="#"><i class="bx bxl-powerpoint"></i> MS PowerPoint  </a></li>
                     <li><a href="#"><i class="bx bxl-access"></i> MS Access  </a></li>
                    </ul>
                </li>
                <li class="drop-down"><a><i class="bx bxl-chrome"></i> Veb sayt</a> 
                    <ul>     
                     <li><a href="#"><i class="bx bxl-html5"></i> HTML 5</a></li>
                     <li><a href="#"><i class="bx bxl-css3"></i> CSS 3  </a></li>
                     <li><a href="#"><i class="bx bxl-javascript"></i> Javasrcipt  </a></li>
                     <li><a href="#"><i class="bx bxl-bootstrap"></i> Boootstrap  </a></li>
                     <li><a href="#"><i class="bx bxl-wordpress"></i> WordPress  </a></li>
                     <li><a href="#"><i class="icofont-evernote"></i> PHP  </a></li>
                    </ul>
                </li>
<li class="drop-down"><a><i class="icofont-computer"></i> Dasturlash</a> 
                    <ul>     
                <li><a href="#"><i class="icofont-file-python"></i> Python  </a></li>
                <li><a href="#"><i class="icofont-computer"></i> Java</a></li>
                <li><a href="#"><i class="icofont-computer"></i> Kotlin  </a></li>
</ul>
</li>
  </ul>
          </li>
          <li class="drop-down"><a><i class="icofont-news"></i> Bo'limlar</a>
          <ul>
          <li class="drop-down"><a><i class="icofont-news"></i> Yangiliklar</a>
                <ul>
                  <li><a href="news.php"><i class="icofont-newspaper"></i> Umumiy</a></li>
                  <li><a href="#"><i class="icofont-newspaper"></i> Kurslar</a></li>
                  <li><a href="#"><i class="icofont-newspaper"></i> Narxlar</a></li>
                  <li><a href="#"><i class="icofont-newspaper"></i> Jamoa</a></li>
                </ul>
          </li>
          

          
          <li class="drop-down"><a><i class="bx bxs-receipt"></i> Loyihalar</a>
            <ul>
                  <li class="drop-down"><a><i class="bx bx-hive"></i> Eng sara taronalar</a>
                    <ul>
                    <li><a href="https://bit.ly/XayrullaAdilov"><i class="bx bx-hive"></i> Xayrulla Adilov</a></li>
                      <li><a href="http://bit.ly/UlugbekMatniyozov"><i class="bx bx-hive"></i> Ulug'bek Matniyozov</a></li>
                      <li><a href="https://bit.ly/AsadbekJumabayev"><i class="bx bx-hive"></i> Asadbek Jumabayev</a></li>
                    </ul>
                  </li>
                  <li class="drop-down"><a><i class="bx bx-edit-alt"></i> Sheriyat</a>
                    <ul>
                      <li><a href="/Jasurbek_Tajibayev.php"><i class="bx bx-edit-alt"></i> Jasurbek Tajibayev</a></li>
                      <li><a href="/rasul_matniyozov.php"><i class="bx bx-edit-alt"></i> Matniyozov Rasulbek</a></li>
                    </ul>
                  </li>
                  <li><a href="#"><i class="bx bxs-extension"></i> Dasturlar</a></li>
                  <li><a href="#"><i class="bx 
bx-mobile"></i> Ilovalar</a></li>
                  <li><a href="#"><i class="bx bx-globe"></i> Veb saytlar</a></li>
            </ul>
        
        </li>
          <li class="drop-down"><a><i class="bx bx-hive"></i> Jamoa</a>
          <ul>
                  <li><a href="/team/index.php"><i class="icofont-user"></i> Barchasi</a></li>
                  <li><a href="#"><i class="icofont-user"></i> O'rinboy Tursunboyev</a></li>
                  <li><a href="#"><i class="icofont-user"></i> Asqor Karimov</a></li>
                  <li><a href="#"><i class="icofont-user"></i> Bexzod Qo'ldoshev</a></li>
                  <li><a href="#"><i class="icofont-user"></i> Muxlisa Olimboyeva</a></li>
                  <li><a href="#"><i class="icofont-user"></i> Quwanish Yuldashev</a></li>
                  <li><a href="#"><i class="icofont-user"></i> Daston Yuldashev</a></li>
                  <li><a href="sheriyat.php"><i class="icofont-user"></i> Jasurbek Tajibayev</a></li>
            </ul>
        
        
        </li>
          <li class="drop-down"><a><i class="icofont-wallet"></i> Narxlar</a>
          <ul>
                  <li><a href="#oddiy"><i class="icofont-wallet"></i> Oddiy</a></li>
                  <li><a href="#boshlang'ich"><i class="icofont-wallet"></i> Boshlang'ich</a></li>
                  <li><a href="#ortacha"><i class="icofont-wallet"></i> O'rtacha daraja</a></li>
                  <li><a href="#yuqori"><i class="icofont-wallet"></i> Yuqori daraja</a></li>
            </ul>
        
        </li>
        </ul>
        </li>
          <li class="drop-down"><a><i class="bx bx-sitemap"></i> Sahifalar</a>
            <ul>
              <li><a href="index.php#about"><i class="bx bxl-stack-overflow"></i>Biz haqimizda</a></li>
              <li><a href="/contact.php"><i class="bx bx-envelope"></i> Bog'lanish</a></li>
              <!-- <li class="drop-down"><a href="#">Deep Drop Down</a>
                <ul>
                  <li><a href="#">Deep Drop Down 1</a></li>
                  <li><a href="#">Deep Drop Down 2</a></li>
                  <li><a href="#">Deep Drop Down 3</a></li>
                  <li><a href="#">Deep Drop Down 4</a></li>
                </ul>
              </li>
              <li><a href="#">Drop Down 2</a></li>
              <li><a href="#">Drop Down 3</a></li> -->
            </ul>
          </li>
          
          <li class="drop-down"><a><i class="bx bx-user"></i> Sayt a'zolariga</a>
            <ul>
            <?php if(!isset($_SESSION['id'])): ?>
              <li><a href="/login.php"><i class="bx bx-log-in"></i> Kirish</a></li>
              <li><a href="/register.php"><i class="bx bx-lock-alt"></i> Ro'yxatdan o'tish</a></li>
            <?php endif; ?>
            <?php if(isset($_SESSION['id'])): ?>
              <li><a href="/users/index.php"><i class="bx bx-id-card"></i> Profil</a></li>
              <li><a href="/users/index.php?logout=1"><i class="bx bx-log-out"></i> Chiqish</a></li>
            <?php endif; ?>
            </ul>
          </li>
        <!-- <li>
        <div class="col-sm-3">
            <div style="margin:0px auto;">
                    <div id="google_translate_element"></div>
                 <div id="google_translate_element"></div>
                <script type="text/javascript">
                function googleTranslateElementInit() {
                new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
                }
                </script>
                <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
                
        
            </div>
        </div>
        </li>-->
        </ul>
      </nav><!-- .nav-menu -->
