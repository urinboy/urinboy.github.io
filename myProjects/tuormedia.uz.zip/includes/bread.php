<!-- ======= Breadcrumbs ======= -->
<section id="breadcrumbs" class="breadcrumbs">
  <div class="container">
    <br>
    <ol>
      <li><a href="/"><i class="icofont-home"></i> Asosiy sahifa</a></li>
      <li><?php echo $title; ?></li>
    </ol>
  </div>
  <h2><?php $title; ?></h2>
</section>

<!-- End Breadcrumbs -->
