<!-- ======= Icon Boxes Section ======= -->
<section id="icon-boxes" class="icon-boxes">
  <div class="container">

    <div class="row">
      <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0" data-aos="fade-up">
        <div class="icon-box" style="text-align:center; font-size:96px;">
          <div class="icon"><i class="icofont-learn" style="font-size:96px;"></i></div>
          <h4 class="title"><a href="">O'qish</a></h4>
          <p class="description">
          Avval o'rgan, keyin o'rgat. <br>
          Bilmasang bilgandan so'ra.<br>
          Bilishim, bilishimga tushar bir ishim</p> 
        </div>
      </div>

      <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0" data-aos="fade-up" data-aos-delay="100">
        <div class="icon-box" style="text-align:center; font-size:96px;">
          <div class="icon"><i class="icofont-institution" style="font-size:96px;"></i></div>
          <h4 class="title"><a href="">Ilm olish</a></h4>
          <p class="description">
              Ilm topmay maqtanma.<br>
              Ilm istasang takror qil.<br>
              Ilmni mehnatsiz egallab bo'mas.
          </p>
        </div>
      </div>

      <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0" data-aos="fade-up" data-aos-delay="200">
        <div class="icon-box" style="text-align:center; font-size:96px;">
          <div class="icon"><i class="icofont-responsive" style="font-size:96px;"></i></div>
          <h4 class="title"><a href="">Moslashish</a></h4>
          <p class="description">
              Zamondan ortta qolma, Bosqaga yalinib qolma<br>
              Bilmagandan bilgan yaxshi, to'gri ishni qilgan yaxshi

          </p>
        </div>
      </div>

      <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0" data-aos="fade-up" data-aos-delay="300">
        <div class="icon-box"  style="text-align:center; font-size:96px;">
          <div class="icon"><i class="icofont-live-support" style="font-size:96px;"></i></div>
          <h4 class="title"><a href="">Universallik</a></h4>
          <p class="description">
              Bir yigitfga yetmish hunar oz.<br>
              Har sohadan bir shingil,<br>
              Qo'lingdan kelsa barini qil.
            </p>
        </div>
      </div>

    </div>

  </div>
</section><!-- End Icon Boxes Section -->
