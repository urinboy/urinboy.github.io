<div class="footer-newsletter">
  <div class="container">
    <div class="row">
      <div class="col-lg-6">
        <h4>Bizga qo'shiling</h4>
        <p>Telegram ijtimoiy tarmog'ida bizga qo'shillish uchun </p>
      </div>
      <div class="col-lg-6">
        <form action="" method="post">
          <input type="email" name="email" placeholder="@tuormedia_uz"><input type="submit" value="Qo'shilish">
        </form>
      </div>
    </div>
  </div>
</div>
<?php if($page_id == 0): ?>
<div class="footer-top">
  <div class="container">
    <div class="row">

      <div class="col-lg-3 col-md-6 footer-links">
        <h4>Bizning sahifalar</h4>
        <ul>
          <li><i class="bx bx-chevron-right"></i> <a href="#">Bosh sahifa</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="#">Biz haqimizda</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="#">Xizmatlar</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="#">Eng sara xizmatlar</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="#">Sayt qoidalari</a></li>
        </ul>
      </div>

      <div class="col-lg-3 col-md-6 footer-links">
        <h4>Bizning xizmatlar</h4>
        <ul>
          <li><i class="bx bx-chevron-right"></i> <a href="#">Veb dizaynlar</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="#">Veb dasturlar</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="#">Startap loyhalar</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="#">Onlayn kurslar</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="#">Oflayn kurslar</a></li>
        </ul>
      </div>

      <div class="col-lg-3 col-md-6 footer-contact">
        <h4>Biz nilan  bog'lanish</h4>
        <p>
          O'zbekiston<br>
          Qoraqalpog'iston Respublikasi<br>
          Taxiatosh tumani, Keneges OFY <br><br>
          <strong>Tel:</strong> +998 91 373 11 96<br>
          <strong>Email:</strong> urinboytursunboev@gmail.com<br>
        </p>

      </div>

      <div class="col-lg-3 col-md-6 footer-info">
        <h3>TUORMedia haqida</h3>
        <p>Biz siz uchun kelajakni birga yaratishga niyat qilganmiz. Bunda sizning  ham O'rningiz beqiyosdir.</p>
        <div class="social-links mt-3">
          <a href="#" class="twitter"><i class="bx bxl-telegram"></i></a>
          <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
          <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
          <a href="#" class="google-plus"><i class="bx bxl-vk"></i></a>
          <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
        </div>
      </div>

    </div>
  </div>
</div>
<?php endif; ?>