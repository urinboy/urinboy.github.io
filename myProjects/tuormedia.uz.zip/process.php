<?php

//process.php validate
$errors = array();
$alert = array();
if ($_SERVER["REQUEST_METHOD"] == "POST") {//Check it is comming from a form

	//mysql credentials
	$mysql_host = "localhost";
	$mysql_username = "root";
	$mysql_password = "";
	$mysql_database = "test";
	
	$u_name = filter_var($_POST["user_name"], FILTER_SANITIZE_STRING); //set PHP variables like this so we can use them anywhere in code below
	$u_email = filter_var($_POST["user_email"], FILTER_SANITIZE_EMAIL);
	$u_text = filter_var($_POST["user_text"], FILTER_SANITIZE_STRING);

	if (empty($u_name)){
		$errors['user_name'] ="Iltimos Imingizni kiriting!";
	}
	if (empty($u_email) || !filter_var($u_email, FILTER_VALIDATE_EMAIL)){
		$errors['user_email'] = "Iltimos yaroqli Elektron manzilingizni kiriting!";
	}
		
	if (empty($u_text)){
		$errors['user_text'] = "Iltimos Xabarni kiriting!";
	}	

	//Open a new connection to the MySQL server
	//see https://www.sanwebe.com/2013/03/basic-php-mysqli-usage for more info
	$mysqli = new mysqli($mysql_host, $mysql_username, $mysql_password, $mysql_database);
	
	//Output any connection error
	if ($mysqli->connect_error) {
		die('Xato : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
	}	
	
	$statement = $mysqli->prepare("INSERT INTO users_data (user_name, user_email, user_message) VALUES(?, ?, ?)"); //prepare sql insert query
	//bind parameters for markers, where (s = string, i = integer, d = double,  b = blob)
	$statement->bind_param('sss', $u_name, $u_email, $u_text); //bind values and execute insert query
	
		
	if($statement->execute()){
		$errors['message'] = "Salom " . $u_name . "! Sizning xabaringiz muvaffaqiyatli jo'natildi!";
		//$errors['alert-class'] = "alert-success";	
	}else{
		$errors['error'] = $mysqli->error; //show mysql error if any
	}
}

$page_id = '';
$page_url = "/process.php";
$title = $errors['message'];
$site_name = "TUORMedia.uz";
include "includes/header.php";
?>

    <!-- ======= Login Section ======= -->
    <section id="login" class="blog">
      <div class="container">
                    
            <div class="row" data-aos="fade-up" data-aos-delay="100">
                <div class="col-md-4 offset-md-4 form-div">
                <form method="post" action="process.php">
                    <div class="section-title" data-aos="fade-up" data-aos-delay="300">
                     <h3 class="text-center"><?php echo $title; ?></h3>
                    </div>
                </form>
                </div>
            </div>
      </div>
    </section><!-- End Login Section -->

	<?php include "includes/footer.php"; ?>