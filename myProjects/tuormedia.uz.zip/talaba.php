<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Talabaning shaxsiy varaqasi</title>
        <style>
            *{
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            body {
                font-size: 13pt;
                background-image:linear-gradient(to right, #15c5a7, #1baab9);
                font-family:'Times New Roman', Times, serif;
                
            }
            a{
                text-decoration: none;
                
            }
            .container{
                width: 90%;
                
                margin: 30px auto;
                padding: 10px;
                background-color: white;
                border-radius: 3px;
                box-shadow: 1px 3px 5px rgba(0,0,0,0.3);
            }
            .row{
                width: 100%;
                height: 100%;
                margin: 20px;
                padding: 15px;
                boeder: 5px solid #ccc;
            }
            .row h4{
            margin:15px auto;
            text-align:center;
            color:#15c5a7;
            font-wiev:bold;
            }
            table{
                width:90%;
                margin: 18px auto;
                padding: 0;
            }
            table tr{
                margin: 5px auto;
                
            }
            table tr td{
                padding-left: 18px;
            }
            table tr td img{
                width:100%;
                box-shadow: 1px 3px 5px rgba(0,0,0,0.3);
            }
            p{
                font-size: 12px;
            }
            .tmargin{
                padding: 20px;
                padding-left: 35px;
                line-height: 25px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="row">
                
            <h4>Muhammad al-Xorazmiy nomidadi Toshkent axborot texnologiyalari<br> universiteti Nukus filiali<br>
            "Kompyuter injiniringi" fakulteti
            </h4>
            <table>
                <tr>
                    <td style="width:20%;">
                       <img src="talaba.jpg" alt="Talaba rasmi">
                    </td>
                    <td class="tmargin">
                        <h4>TALABANING SHAXSIY VARAQASI</h4>
                        <p style="margin-left:60px;">
                            <center>Yig`ma jild va reyting daftarchasi No <b>  1061911</b></center><br>
                            Mutaxassislik "<b>Kompyuter injinitingi: AT-Servis</b>"<br>
                            F.I.Sh: <b>  TURSUNBOYEV  O'RINBOY   ODILOVICH</b>
                            
                        </p>
                    </td>
                </tr>
            </table>
            <br>
            <table style="height:30vh;">
                <tr>
                    <td>1.</td>
                    <td>Tug`ilgan yili, oyi, kuni</td>
                    <td>1996.05.10</td>
                </tr>
                <tr>
                    <td>2.</td>
                    <td>Tug`ilgan joyi</td>
                    <td>Qoraqalpog`iston Respublikasi, Xo`jayli tumani</td>
                </tr>
                <tr>
                    <td>3.</td>
                    <td>Millati</td>
                    <td>O`zbek</td>
                </tr>
                <tr>
                    <td>4.</td>
                    <td>Ma'lumoti (maktab, akademik litsey, KHK yoki boshqa o`quv yurti N# nomi tugatgan yili</td>
                    <td>Xo'jayli Pedagogika kolleji</td>
                </tr>
                <tr>
                    <td>5.</td>
                    <td>O`qishga kirgunga qadar ish joyi, mansabi (agar ishlagan bo`lsa)</td>
                    <td>Taxiatosh tibbiyot birlashmasiga qarashli Keneges qishloq vrachlik punkti, posbon.</td>
                </tr>
                <tr>
                    <td>6.</td>
                    <td>Ota-ona haqida ma'lumot (F.I.Sh qayerda kim bo`lib ishlaydi, telefon raqami</td>
                    <td></td>
                </tr>
                <tr>
                    <td>7.</td>
                    <td>Oilaviy axvoli (turmush o`rtog`ining F.I.Sh qayerda, kim bo`lib ishlaydi telefon raqami</td>
                    <td></td>
                </tr>
                <tr>
                    <td>8.</td>
                    <td>Pasport seriyasi, raqami, kim tomonidan, qachon berilga</td>
                    <td></td>
                </tr>
                <tr>
                    <td>9.</td>
                    <td>Ota-onasining yashash manzili</td>
                    <td></td>
                </tr>
                <tr>
                    <td>10.</td>
                    <td>Uy manzili, shu jumladan ijara uy, telefoni</td>
                    <td></td>
                </tr>
            </table>
            </div>
        </div>
    </body>
</html>