<!DOCTYPE html>
<html lang="<?= $lang;?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE-edge">
        <meta name="viewport" content="width=device-width, intial-scale=1.0">
        <title><?= $title;?></title>
        <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
        <link rel="stylesheet" href="assets/style.css">
        <!--using FontAwesome---------------->
	    <script src="https://kit.fontawesome.com/c8e4d183c2.js" crossorigin="anonymous"></script>

    </head>
    <body>
        <?php include 'nav.php';?>