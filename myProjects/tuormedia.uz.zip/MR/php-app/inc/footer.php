<footer>
	 <!--heading-->
  <p>TUORMedia</p>
	 <!--paragraph-->
	 <p>I makeas soon as possibale.You really like my work,if you don&#8217;t i change this until you like I give you seticfaction result</p>
	 <!--social-->
	<div class="social-icons">
	<a href="#"><i class="fab fa-facebook-f"></i></a>
	<a href="#"><i class="fab fa-twitter"></i></a>
	<a href="#"><i class="fab fa-instagram"></i></a>
	<a href="#"><i class="fab fa-youtube"></i></a>
	</div>
	 <!--copyright-->
	 <p class="copyright">&copy; 2021 TUORMedia.uz</p>
</footer>
	<!--social-attach-bar-->
	<div class="social">
	<a href="#"><i class="fab fa-facebook-f"></i></a>
	<a href="#"><i class="fab fa-twitter"></i></a>
	<a href="#"><i class="fab fa-instagram"></i></a>
	<a href="#"><i class="fab fa-youtube"></i></a>
	</div>
   <!--JQUery-------------------->
<script type="text/javascript" src="assets/js/JQuery.js"></script>
	<script type="text/javascript">
	$(document).ready(function(){
		$('.toggle').click(function(){
			$('.toggle').toggleClass('active')
			$('nav').toggleClass('active')
		})
	})
	</script>
    </body>
</html>