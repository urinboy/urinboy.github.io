<section>
	<!--navigation------------------------->
		<nav>
		<!--logo-->
			<a href="#" class="logo">tuormedia.uz</a>
		<!--menu-->
			<ul>
				<li><a href="#" class="active">Home</a></li>
				<li><a href="#about">About</a></li>
				<li><a href="#servises">Servises</a></li>
				<li><a href="#contact">Contact us</a></li>
			</ul>
		<!--bars--------------->
		<div class="toggle"></div>
		
		</nav>
    </section>
